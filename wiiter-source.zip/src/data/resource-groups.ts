export interface ResourceCard {
  name: string;
  description: string;
  href: string;
}

export interface ResourceGroup {
  id: "repair" | "donate" | "sell" | "recycle";
  title: string;
  cards: ResourceCard[];
}

// Editorial directory content from the user's references, with official destinations.
export const resourceGroups: ResourceGroup[] = [
  {
    id: "repair", title: "Repair", cards: [
      { name: "Repair Café Basel", description: "Volunteers help you repair everyday objects and clothes at community events.", href: "https://www.reparier-bar.ch/" },
      { name: "Reparaturführer Schweiz", description: "Directory of repair shops near you.", href: "https://www.reparaturfuehrer.ch/" },
    ],
  },
  {
    id: "donate", title: "Donate & give away", cards: [
      { name: "Brockenhaus / Brocki Basel", description: "Accepts well-preserved furniture and household goods. Check current donation needs.", href: "https://www.blaukreuz-brocki.ch/standorte/blaukreuz-brockenhalle-basel" },
      { name: "Heilsarmee Brocki", description: "Secondhand shop in Pratteln for furniture, dishes, clothes and books.", href: "https://www.brocki.ch/de/filialen/pratteln/" },
      { name: "HIOB Brockenhaus", description: "Charity secondhand stores, some with pickup service.", href: "https://hiob.ch/brockenstuben/basel/" },
      { name: "Brocki-Verzeichnis Basel", description: "Find secondhand stores in and around Basel.", href: "https://www.brockisearch.ch/brockenhaeuser/basel-stadt/" },
      { name: "Caritas beider Basel", description: "Secondhand shops supporting people on low incomes.", href: "https://caritas-regio.ch/angebote/guenstiger-leben/secondhand-brocki" },
      { name: "HEKS Basel", description: "Local aid organisation. Ask about current donation opportunities.", href: "https://www.heks.ch/" },
      { name: "Texaid Kleidersammlung", description: "Find containers for clean clothes and wearable shoes around Basel.", href: "https://www.texaid.ch/de/produkte-leistungen/sammlung/containersammlung.html" },
      { name: "Facebook-Gruppe «Basel zu verschenken»", description: "Find local groups for giving items away to neighbours.", href: "https://www.facebook.com/search/groups/?q=Basel%20zu%20verschenken" },
    ],
  },
  {
    id: "sell", title: "Sell", cards: [
      { name: "Ricardo", description: "Biggest Swiss online marketplace, great for electronics.", href: "https://ricardo.ch/de" },
      { name: "Tutti.ch", description: "Classifieds, ideal for furniture with pickup.", href: "https://www.tutti.ch/" },
      { name: "Flohmarkt Petersplatz", description: "Traditional flea market every Saturday at Petersplatz.", href: "https://www.bs.ch/veranstaltungen/flohmarkt-petersplatz" },
    ],
  },
  {
    id: "recycle", title: "Recycle", cards: [
      { name: "SENS eRecycling Rücknahme", description: "Return electronics for free at any shop that sells them.", href: "https://www.erecycling.ch/en/privatpersonen/elektrogeraete-entsorgen/sammelstellen-finden.html" },
      { name: "Recycling-Sammelstellen Basel-Stadt", description: "Glass, PET, aluminium, paper and metal at local collection points.", href: "https://www.bs.ch/themen/umwelt-und-bauen/abfall-und-sauberkeit/sammelstellen" },
    ],
  },
];