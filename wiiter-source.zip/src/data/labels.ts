import type { ActionType, Condition, ItemCategory, OutcomeType, Priority, Transport } from "./types";

export const itemLabels: Record<ItemCategory, string> = {
  electrical: "Lamp or small electrical item",
  textiles: "Clothing or textiles",
  tool: "Tool or household object",
  other: "Other item",
};
export const conditionLabels: Record<Condition, string> = {
  works: "Works well",
  damaged: "Damaged but usable",
  broken: "Broken or not working",
  unsure: "Unsure",
};
export const priorityLabels: Record<Priority, string> = {
  "second-life": "Give it a second life",
  cheap: "Spend as little as possible",
  convenient: "Get rid of it conveniently",
  repair: "Find a repair option",
};
export const transportLabels: Record<Transport, string> = {
  walk: "Walking",
  transit: "Public transport",
  car: "Car",
  collection: "I need a collection option",
};
export const actionLabels: Record<ActionType, string> = {
  repair: "Repair",
  donate: "Give away",
  resell: "Resell or pass on",
  reuse: "Reuse",
  borrow: "Borrow & share",
  recycle: "Recycle",
};
export const outcomeLabels: Record<OutcomeType, string> = {
  repaired: "Repaired",
  donated: "Donated",
  sold: "Sold or passed on",
  reused: "Reused",
  recycled: "Recycled",
  unresolved: "Not resolved yet",
};
