export type ItemCategory = "electrical" | "textiles" | "tool" | "other";
export type Condition = "works" | "damaged" | "broken" | "unsure";
export type Priority = "second-life" | "cheap" | "convenient" | "repair";
export type Transport = "walk" | "transit" | "car" | "collection";
export type ActionType = "repair" | "donate" | "resell" | "reuse" | "borrow" | "recycle";
export type OutcomeType = "repaired" | "donated" | "sold" | "reused" | "recycled" | "unresolved";

export interface Answers {
  item?: ItemCategory | undefined;
  condition?: Condition | undefined;
  priority?: Priority | undefined;
  transport?: Transport | undefined;
}

export type DirectoryCategory = "repair" | "donate" | "reuse" | "recycle" | "collection" | "events" | "resell" | "borrow";
export type DirectoryItem = "electronics" | "furniture" | "clothing" | "bikes" | "household" | "books" | "toys" | "appliances" | "other";

export interface OptionEntry {
  id: string;
  itemCategory: ItemCategory[];
  actionType: ActionType;
  title: string;
  description: string;
  eligibilityNotes: string;
  nextSteps: string[];
  sourceUrl: string | null;
  verificationStatus: "verified" | "example" | "community" | "official";
  directoryCategories?: DirectoryCategory[];
  directoryItems?: DirectoryItem[];
  location?: string;
  address?: string;
  phone?: string;
  hours?: string;
  cost?: string;
  free?: boolean;
  appointmentRequired?: boolean;
  acceptsDamaged?: boolean;
  pickupAvailable?: boolean;
  checkedAt?: string;
}

export type CompleteAnswers = { [K in keyof Answers]-?: NonNullable<Answers[K]> };
