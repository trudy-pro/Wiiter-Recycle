import type { DirectoryCategory, DirectoryItem } from "./types";

export const directoryLabels: Record<DirectoryCategory, string> = {
  repair: "Repair", donate: "Donate", reuse: "Reuse", recycle: "Recycle", collection: "Collection points", events: "Events", resell: "Resell", borrow: "Borrow & share",
};
export const directoryItemLabels: Record<DirectoryItem, string> = {
  electronics: "Electronics", furniture: "Furniture", clothing: "Clothing", bikes: "Bikes", household: "Household", books: "Books", toys: "Toys", appliances: "Appliances", other: "Other",
};