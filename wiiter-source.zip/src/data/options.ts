import type { OptionEntry } from "./types";

// Demo dataset. All entries are illustrative examples, not real providers.
// Set verificationStatus to "verified" and add a sourceUrl only after checking a real source.
const exampleOptions: OptionEntry[] = [
  {
    id: "ex-repair-cafe",
    itemCategory: ["electrical", "textiles", "tool", "other"],
    actionType: "repair",
    title: "Example: neighbourhood repair café",
    description: "Events run by volunteers where residents fix items together with experienced helpers.",
    eligibilityNotes: "Typically small, portable items you can carry in. Safety rules may apply to electrical items.",
    nextSteps: ["Check the next event date", "Bring the item and any parts", "Describe the fault clearly"],
    sourceUrl: null,
    verificationStatus: "example",
  },
  {
    id: "ex-electronics-repair",
    itemCategory: ["electrical"],
    actionType: "repair",
    title: "Example: small electronics repair workshop",
    description: "A commercial workshop that diagnoses and repairs lamps and small appliances.",
    eligibilityNotes: "Usually charges a diagnosis fee. Ask for a quote before work begins.",
    nextSteps: ["Request a cost estimate", "Compare with replacement cost"],
    sourceUrl: null,
    verificationStatus: "example",
  },
  {
    id: "ex-tailor",
    itemCategory: ["textiles"],
    actionType: "repair",
    title: "Example: tailoring and alterations shop",
    description: "Fixes seams, zips, hems and small tears in clothing.",
    eligibilityNotes: "Item should be clean. Prices vary by repair.",
    nextSteps: ["Wash the item", "Ask for a price before leaving it"],
    sourceUrl: null,
    verificationStatus: "example",
  },
  {
    id: "ex-second-hand-shop",
    itemCategory: ["textiles", "tool", "other", "electrical"],
    actionType: "donate",
    title: "Example: charity secondhand shop",
    description: "Accepts donations of clean, working items to resell for a social cause.",
    eligibilityNotes: "Usually only items in good, working condition. Electrical items may be refused.",
    nextSteps: ["Confirm what they currently accept", "Clean the item", "Drop off during opening hours"],
    sourceUrl: null,
    verificationStatus: "example",
  },
  {
    id: "ex-clothing-collection",
    itemCategory: ["textiles"],
    actionType: "donate",
    title: "Example: clothing collection container",
    description: "Public containers for wearable clothing and shoes.",
    eligibilityNotes: "Typically clean, dry, wearable textiles in closed bags.",
    nextSteps: ["Bag the textiles", "Find the nearest container"],
    sourceUrl: null,
    verificationStatus: "example",
  },
  {
    id: "ex-marketplace",
    itemCategory: ["electrical", "textiles", "tool", "other"],
    actionType: "resell",
    title: "Example: online secondhand marketplace",
    description: "Sell or give away items to people nearby through an online listing.",
    eligibilityNotes: "Describe condition honestly, including any defects.",
    nextSteps: ["Take clear photos", "Describe condition honestly", "Agree a safe handover"],
    sourceUrl: null,
    verificationStatus: "example",
  },
  {
    id: "ex-give-box",
    itemCategory: ["textiles", "tool", "other"],
    actionType: "reuse",
    title: "Example: neighbourhood giveaway box",
    description: "A shelf or box where neighbours leave and take small usable items for free.",
    eligibilityNotes: "Small, clean, usable items only. Not for broken goods.",
    nextSteps: ["Check the box is not full", "Leave only usable items"],
    sourceUrl: null,
    verificationStatus: "example",
  },
  {
    id: "ex-upcycling",
    itemCategory: ["textiles", "other", "tool"],
    actionType: "reuse",
    title: "Example: upcycling or craft workshop",
    description: "Groups that turn materials from old items into something new.",
    eligibilityNotes: "Often interested in specific materials such as fabric, wood or metal.",
    nextSteps: ["Ask which materials they need"],
    sourceUrl: null,
    verificationStatus: "example",
  },
  {
    id: "ex-library-of-things",
    itemCategory: ["tool", "electrical", "other"],
    actionType: "borrow",
    title: "Example: library of things",
    description: "Borrow tools and appliances instead of buying them — and sometimes donate working ones.",
    eligibilityNotes: "Membership may be required. Donated items must be complete and working.",
    nextSteps: ["Check membership terms", "Ask whether they accept donations"],
    sourceUrl: null,
    verificationStatus: "example",
  },
  {
    id: "ex-electrical-takeback",
    itemCategory: ["electrical"],
    actionType: "recycle",
    title: "Example: retailer takeback for electrical items",
    description: "Shops selling electrical goods may take back old devices for proper recycling.",
    eligibilityNotes: "Conditions vary by shop and device type. Remove batteries if possible.",
    nextSteps: ["Ask the shop if they accept this device type", "Remove batteries separately"],
    sourceUrl: null,
    verificationStatus: "example",
  },
  {
    id: "ex-recycling-point",
    itemCategory: ["textiles", "tool", "other", "electrical"],
    actionType: "recycle",
    title: "Example: municipal recycling point",
    description: "Collection points for separated materials such as metal, textiles or electronics.",
    eligibilityNotes: "Each point accepts specific materials only. Check the official city guidance.",
    nextSteps: ["Separate materials", "Check what the point accepts"],
    sourceUrl: null,
    verificationStatus: "example",
  },
];


const exampleFacets: Record<string, { directoryCategories: NonNullable<OptionEntry["directoryCategories"]>; directoryItems: NonNullable<OptionEntry["directoryItems"]> }> = {
  "ex-repair-cafe": { directoryCategories: ["repair", "events"], directoryItems: ["electronics", "appliances", "household", "clothing", "other"] },
  "ex-electronics-repair": { directoryCategories: ["repair"], directoryItems: ["electronics", "appliances"] },
  "ex-tailor": { directoryCategories: ["repair"], directoryItems: ["clothing"] },
  "ex-second-hand-shop": { directoryCategories: ["donate", "reuse"], directoryItems: ["furniture", "clothing", "books", "toys", "household", "electronics"] },
  "ex-clothing-collection": { directoryCategories: ["donate", "collection"], directoryItems: ["clothing"] },
  "ex-marketplace": { directoryCategories: ["resell", "reuse"], directoryItems: ["electronics", "furniture", "clothing", "bikes", "household", "books", "toys", "appliances", "other"] },
  "ex-give-box": { directoryCategories: ["reuse"], directoryItems: ["books", "toys", "household", "other"] },
  "ex-upcycling": { directoryCategories: ["reuse", "events"], directoryItems: ["clothing", "furniture", "household", "other"] },
  "ex-library-of-things": { directoryCategories: ["borrow", "reuse"], directoryItems: ["household", "appliances", "other"] },
  "ex-electrical-takeback": { directoryCategories: ["recycle", "collection"], directoryItems: ["electronics", "appliances"] },
  "ex-recycling-point": { directoryCategories: ["recycle", "collection"], directoryItems: ["household", "electronics", "other"] },
};
const localOptions: OptionEntry[] = [
  {
    "id": "basel-reparierbar",
    "title": "reparierBar Basel",
    "actionType": "repair",
    "itemCategory": [
      "electrical",
      "textiles",
      "tool",
      "other"
    ],
    "directoryCategories": [
      "repair",
      "events"
    ],
    "directoryItems": [
      "electronics",
      "appliances",
      "clothing",
      "household",
      "other"
    ],
    "description": "Community repair events for everyday objects and clothing.",
    "eligibilityNotes": "Venues and accepted items vary by event.",
    "nextSteps": [
      "Check the next event date",
      "Bring the item and any parts"
    ],
    "sourceUrl": "https://www.reparier-bar.ch/",
    "verificationStatus": "official",
    "checkedAt": "2026-10-24",
    "location": "Basel · rotating event venues",
    "acceptsDamaged": true
  },
  {
    "id": "repair-directory",
    "title": "Reparaturführer.ch",
    "actionType": "repair",
    "itemCategory": [
      "electrical",
      "textiles",
      "tool",
      "other"
    ],
    "directoryCategories": [
      "repair"
    ],
    "directoryItems": [
      "electronics",
      "furniture",
      "clothing",
      "bikes",
      "household",
      "appliances",
      "other"
    ],
    "description": "Find repair businesses, advice and events in the Basel area.",
    "eligibilityNotes": "A search directory, not a physical drop off point.",
    "nextSteps": [
      "Choose a Basel area business",
      "Ask for a cost estimate"
    ],
    "sourceUrl": "https://www.reparaturfuehrer.ch/",
    "verificationStatus": "official",
    "checkedAt": "2026-10-24",
    "location": "Online · Basel area search"
  },
  {
    "id": "basel-blaukreuz",
    "title": "Blaukreuz-Brockenhalle Basel",
    "actionType": "donate",
    "itemCategory": [
      "electrical",
      "textiles",
      "tool",
      "other"
    ],
    "directoryCategories": [
      "donate",
      "reuse"
    ],
    "directoryItems": [
      "furniture",
      "electronics",
      "appliances",
      "clothing",
      "household",
      "toys"
    ],
    "description": "Secondhand shop accepting well preserved goods for resale.",
    "eligibilityNotes": "Confirm current donation needs and item condition before visiting.",
    "nextSteps": [
      "Confirm what they currently accept",
      "Clean the item"
    ],
    "sourceUrl": "https://www.blaukreuz-brocki.ch/standorte/blaukreuz-brockenhalle-basel",
    "verificationStatus": "official",
    "checkedAt": "2026-10-24",
    "location": "Basel · Dreispitz",
    "address": "Leimgrubenweg 9, 4053 Basel",
    "phone": "+41614612011",
    "hours": "Tue to Fri 12:00 to 18:00 · Sat 10:00 to 16:00"
  },
  {
    "id": "basel-hiob",
    "title": "HIOB Brockenstube Basel",
    "actionType": "donate",
    "itemCategory": [
      "textiles",
      "tool",
      "other"
    ],
    "directoryCategories": [
      "donate",
      "reuse"
    ],
    "directoryItems": [
      "furniture",
      "household",
      "clothing",
      "books"
    ],
    "description": "Secondhand household goods and furniture, with regional collections.",
    "eligibilityNotes": "Ask the branch whether your goods are suitable for donation.",
    "nextSteps": [
      "Confirm what they currently accept",
      "Ask about collection conditions"
    ],
    "sourceUrl": "https://hiob.ch/brockenstuben/basel/",
    "verificationStatus": "official",
    "checkedAt": "2026-10-24",
    "location": "Basel · Klybeck",
    "address": "Klybeckstrasse 91, 4057 Basel",
    "phone": "+41616832360",
    "hours": "Mon to Fri 09:00 to 18:30 · Sat 10:00 to 18:00",
    "pickupAvailable": true
  },
  {
    "id": "pratteln-brocki",
    "title": "Heilsarmee brocki.ch Pratteln",
    "actionType": "donate",
    "itemCategory": [
      "textiles",
      "tool",
      "other"
    ],
    "directoryCategories": [
      "donate",
      "reuse"
    ],
    "directoryItems": [
      "furniture",
      "clothing",
      "books",
      "household"
    ],
    "description": "Regional secondhand shop for furniture, clothing, books and household goods.",
    "eligibilityNotes": "Contact the branch before bringing donations.",
    "nextSteps": [
      "Confirm what they currently accept",
      "Clean the item"
    ],
    "sourceUrl": "https://www.brocki.ch/de/filialen/pratteln/",
    "verificationStatus": "official",
    "checkedAt": "2026-10-24",
    "location": "Pratteln · Rüti Center",
    "address": "Rütiweg 9, 4133 Pratteln",
    "phone": "+41613315788",
    "hours": "Mon to Fri 09:00 to 18:30 · Sat 09:00 to 17:00"
  },
  {
    "id": "basel-caritas",
    "title": "Caritas Secondhand Basel",
    "actionType": "donate",
    "itemCategory": [
      "textiles",
      "other"
    ],
    "directoryCategories": [
      "donate",
      "reuse"
    ],
    "directoryItems": [
      "clothing",
      "toys"
    ],
    "description": "Secondhand clothing, shoes, accessories and toys.",
    "eligibilityNotes": "Confirm Basel donation arrangements directly with Caritas.",
    "nextSteps": [
      "Confirm what they currently accept",
      "Bag the textiles"
    ],
    "sourceUrl": "https://caritas-regio.ch/angebote/guenstiger-leben/secondhand-brocki",
    "verificationStatus": "official",
    "checkedAt": "2026-10-24",
    "location": "Basel · Lindenberg",
    "address": "Lindenberg 18–20, 4058 Basel"
  },
  {
    "id": "basel-offcut",
    "title": "OFFCUT Basel",
    "actionType": "reuse",
    "itemCategory": [
      "textiles",
      "tool",
      "other"
    ],
    "directoryCategories": [
      "reuse"
    ],
    "directoryItems": [
      "clothing",
      "household",
      "other"
    ],
    "description": "Reusable surplus materials for creative projects instead of new purchases.",
    "eligibilityNotes": "Ask which fabrics, wood and other materials are currently wanted.",
    "nextSteps": [
      "Ask which materials they need"
    ],
    "sourceUrl": "https://www.offcut.ch/bs/de",
    "verificationStatus": "official",
    "checkedAt": "2026-10-24",
    "location": "Basel · Dreispitz",
    "address": "Lyon-Strasse 11, 4053 Basel",
    "phone": "+41613310636",
    "hours": "Mon to Fri 11:00 to 18:00 · Sat 10:00 to 17:00"
  },
  {
    "id": "basel-leihlager",
    "title": "Leihlager Basel",
    "actionType": "borrow",
    "itemCategory": [
      "electrical",
      "tool",
      "other"
    ],
    "directoryCategories": [
      "borrow",
      "reuse"
    ],
    "directoryItems": [
      "household",
      "appliances",
      "other"
    ],
    "description": "Borrow everyday equipment and tools rather than buying them.",
    "eligibilityNotes": "Check availability, membership and lending terms.",
    "nextSteps": [
      "Check membership terms",
      "Check equipment availability"
    ],
    "sourceUrl": "https://leihlager.ch/en/",
    "verificationStatus": "official",
    "checkedAt": "2026-10-24",
    "location": "Basel · Klybeck",
    "address": "Horburgstrasse 103, 4057 Basel",
    "phone": "+41762132949"
  },
  {
    "id": "sens-recycling",
    "title": "SENS eRecycling",
    "actionType": "recycle",
    "itemCategory": [
      "electrical"
    ],
    "directoryCategories": [
      "recycle",
      "collection"
    ],
    "directoryItems": [
      "electronics",
      "appliances"
    ],
    "description": "Find collection points for responsible electrical appliance recycling.",
    "eligibilityNotes": "Return covered appliances to a collection point or retailer selling that type.",
    "nextSteps": [
      "Find a Basel collection point on the provider website",
      "Remove batteries separately"
    ],
    "sourceUrl": "https://www.erecycling.ch/en/privatpersonen/elektrogeraete-entsorgen/sammelstellen-finden.html",
    "verificationStatus": "official",
    "checkedAt": "2026-10-24",
    "location": "Basel area · collection point finder",
    "cost": "Free return of covered appliances",
    "free": true,
    "acceptsDamaged": true
  },
  {
    "id": "basel-city-collection",
    "title": "Basel-Stadt collection points",
    "actionType": "recycle",
    "itemCategory": [
      "tool",
      "other"
    ],
    "directoryCategories": [
      "recycle",
      "collection"
    ],
    "directoryItems": [
      "household",
      "other"
    ],
    "description": "Official collection point directory for glass, metal, batteries and textiles.",
    "eligibilityNotes": "Each point accepts specific materials only. Check the official city guidance.",
    "nextSteps": [
      "Separate materials",
      "Check what the point accepts"
    ],
    "sourceUrl": "https://www.bs.ch/themen/umwelt-und-bauen/abfall-und-sauberkeit/sammelstellen",
    "verificationStatus": "official",
    "checkedAt": "2026-10-24",
    "location": "Basel-Stadt · multiple collection points"
  },
  {
    "id": "texaid-collection",
    "title": "TEXAID textile collection",
    "actionType": "donate",
    "itemCategory": [
      "textiles"
    ],
    "directoryCategories": [
      "donate",
      "collection"
    ],
    "directoryItems": [
      "clothing"
    ],
    "description": "Collection containers for clean clothing, household textiles and wearable shoes.",
    "eligibilityNotes": "No heavily soiled textiles or fabric offcuts. Bag items securely.",
    "nextSteps": [
      "Bag the textiles",
      "Find the nearest container"
    ],
    "sourceUrl": "https://www.texaid.ch/de/produkte-leistungen/sammlung/containersammlung.html",
    "verificationStatus": "official",
    "checkedAt": "2026-10-24",
    "location": "Basel area · container finder"
  },
  {
    "id": "ricardo",
    "title": "Ricardo",
    "actionType": "resell",
    "itemCategory": [
      "electrical",
      "textiles",
      "tool",
      "other"
    ],
    "directoryCategories": [
      "resell",
      "reuse"
    ],
    "directoryItems": [
      "electronics",
      "furniture",
      "clothing",
      "bikes",
      "household",
      "books",
      "toys",
      "appliances",
      "other"
    ],
    "description": "Online resale and local handover of reusable items.",
    "eligibilityNotes": "An online platform, not a drop off point. Fees and pickup depend on the listing.",
    "nextSteps": [
      "Take clear photos",
      "Describe condition honestly",
      "Agree a safe handover"
    ],
    "sourceUrl": "https://ricardo.ch/de",
    "verificationStatus": "official",
    "checkedAt": "2026-10-24",
    "location": "Online · local handover"
  },
  {
    "id": "tutti",
    "title": "tutti.ch",
    "actionType": "resell",
    "itemCategory": [
      "electrical",
      "textiles",
      "tool",
      "other"
    ],
    "directoryCategories": [
      "resell",
      "reuse"
    ],
    "directoryItems": [
      "electronics",
      "furniture",
      "clothing",
      "bikes",
      "household",
      "books",
      "toys",
      "appliances",
      "other"
    ],
    "description": "Online resale and local handover of reusable items.",
    "eligibilityNotes": "An online platform, not a drop off point. Fees and pickup depend on the listing.",
    "nextSteps": [
      "Take clear photos",
      "Describe condition honestly",
      "Agree a safe handover"
    ],
    "sourceUrl": "https://www.tutti.ch/",
    "verificationStatus": "official",
    "checkedAt": "2026-10-24",
    "location": "Online · local handover"
  }
];

export const options: OptionEntry[] = [...localOptions, ...exampleOptions.map((entry) => ({ ...entry, ...exampleFacets[entry.id] }))];
