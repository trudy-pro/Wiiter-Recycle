// Illustrative rows from the project brief. They are shown on the Impact page as an
// example of what the history looks like — they are never counted in the impact cards.
export type ImpactExample = {
  item: string;
  action: string;
  detail: string;
  tag: string;
};

export const impactExamples: ImpactExample[] = [
  {
    item: "Old chair",
    action: "Given away",
    detail: "1 item given a second life · Approx. 8 kg waste avoided",
    tag: "Donated",
  },
  {
    item: "Laptop",
    action: "Recycled",
    detail: "Electronics recycled responsibly · Approx. 4 kg waste avoided",
    tag: "Recycled",
  },
  {
    item: "Jacket",
    action: "Resold",
    detail: "Item reused · CHF 25 value recovered",
    tag: "Resold",
  },
];

// Example outcomes used only for the Impact empty state (never mixed with real records).
import type { OutcomeRecord } from "@/lib/store";
export const exampleOutcomes: (OutcomeRecord & { name: string })[] = [
  { id: "ex1", name: "Cordless drill", item: "tool", action: "resell", outcome: "sold", date: "2026-10-01" },
  { id: "ex2", name: "Jacket", item: "textiles", action: "resell", outcome: "sold", date: "2026-10-05" },
  { id: "ex3", name: "Desk lamp", item: "other", action: "donate", outcome: "donated", date: "2026-10-10" },
  { id: "ex4", name: "Toaster", item: "electrical", action: "reuse", outcome: "reused", date: "2026-10-15" },
];
