import repairWorkshop from "@/assets/repair-workshop.webp.asset.json";
import toolsShop from "@/assets/tools-shop.avif.asset.json";
import electronicsRepair from "@/assets/electronics-repair.avif.asset.json";
import secondhandShop from "@/assets/secondhand-shop.avif.asset.json";
import thriftStore from "@/assets/thrift-store.avif.asset.json";
import clothesRack from "@/assets/clothes-rack.avif.asset.json";

// Illustrative card images shared across option entries; not provider photographs.
export const optionImages: Record<string, string> = {
  "basel-reparierbar": repairWorkshop.url,
  "repair-directory": electronicsRepair.url,
  "basel-blaukreuz": secondhandShop.url,
  "basel-hiob": thriftStore.url,
  "pratteln-brocki": secondhandShop.url,
  "basel-caritas": clothesRack.url,
  "basel-offcut": toolsShop.url,
  "basel-leihlager": toolsShop.url,
  "sens-recycling": electronicsRepair.url,
  "basel-city-collection": repairWorkshop.url,
  "texaid-collection": clothesRack.url,
  "ricardo": thriftStore.url,
  "tutti": thriftStore.url,

  "ex-repair-cafe": repairWorkshop.url,
  "ex-electronics-repair": electronicsRepair.url,
  "ex-tailor": clothesRack.url,
  "ex-second-hand-shop": secondhandShop.url,
  "ex-clothing-collection": clothesRack.url,
  "ex-marketplace": thriftStore.url,
  "ex-give-box": thriftStore.url,
  "ex-upcycling": toolsShop.url,
  "ex-library-of-things": toolsShop.url,
  "ex-electrical-takeback": electronicsRepair.url,
  "ex-recycling-point": repairWorkshop.url,
};
