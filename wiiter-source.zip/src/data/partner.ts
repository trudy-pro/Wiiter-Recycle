/** Demo partner portal data. Replace with live organization data once a backend exists. */

export type PartnerRole = "Admin" | "Editor" | "Verifier" | "Viewer";
export type VerificationStatus = "Verified" | "Needs review" | "Outdated" | "Draft";
export type CategoryStatus = "Accepted" | "Conditionally accepted" | "Not accepted";
export type ReportStatus = "Open" | "Confirmed" | "Resolved" | "Rejected";

export interface PartnerOrg {
  id: string;
  name: string;
}

export interface PartnerLocation {
  id: string;
  orgId: string;
  name: string;
  address: string;
  hours: string;
  phone: string;
  website: string;
  active: boolean;
  temporarilyClosed: boolean;
  notes: string;
  lastVerified: string;
  status: VerificationStatus;
}

export interface PartnerCategory {
  id: string;
  orgId: string;
  category: string;
  status: CategoryStatus;
  functional: boolean;
  minorCosmetic: boolean;
  missingParts: boolean;
  severeDamage: boolean;
  notes: string;
  lastVerified: string;
  verificationStatus: VerificationStatus;
}

export interface RoutingRule {
  id: string;
  orgId: string;
  code: string;
  category: string;
  condition: string;
  damageSeverity: string;
  recommend: string;
  confidenceModifier: number;
  alternative: string;
  status: VerificationStatus;
  lastVerified: string;
}

export interface UserReport {
  id: string;
  orgId: string;
  type: string;
  target: string;
  date: string;
  comment: string;
  currentData: string;
  status: ReportStatus;
}

export interface HistoryEvent {
  id: string;
  orgId: string;
  date: string;
  user: string;
  change: string;
  oldValue: string;
  newValue: string;
}

export const partnerOrgs: PartnerOrg[] = [
  { id: "pretty-good", name: "Pretty Good Basel" },
  { id: "bs-recycling", name: "Basel-Stadt Recycling" },
];

export const demoLocations: PartnerLocation[] = [
  { id: "lottner", orgId: "pretty-good", name: "Lottner AG", address: "Address to be confirmed", hours: "Mon to Fri, 8 to 17", phone: "+41 61 000 00 00", website: "https://www.bs.ch", active: true, temporarilyClosed: false, notes: "Main collection point for reusable household goods.", lastVerified: "2026-10-18", status: "Verified" },
  { id: "riehen", orgId: "pretty-good", name: "Werkhof / Recyclingpark Riehen", address: "Address to be confirmed", hours: "Mon to Sat, 8 to 16", phone: "+41 61 000 00 01", website: "https://www.bs.ch", active: true, temporarilyClosed: false, notes: "Accepts bulky reusable items.", lastVerified: "2026-10-18", status: "Verified" },
  { id: "aeschenplatz", orgId: "pretty-good", name: "Mobile collection Aeschenplatz", address: "Aeschenplatz, Basel", hours: "First Saturday of the month", phone: "", website: "", active: true, temporarilyClosed: true, notes: "Paused during construction work.", lastVerified: "2026-06-02", status: "Outdated" },
  { id: "hof-west", orgId: "bs-recycling", name: "Recyclinghof Basel West", address: "Address to be confirmed", hours: "Mon to Fri, 7 to 18", phone: "+41 61 000 00 02", website: "https://www.bs.ch", active: true, temporarilyClosed: false, notes: "", lastVerified: "2026-10-10", status: "Verified" },
  { id: "hof-breite", orgId: "bs-recycling", name: "Recyclinghof Breite", address: "Address to be confirmed", hours: "Mon to Sat, 8 to 17", phone: "+41 61 000 00 03", website: "https://www.bs.ch", active: true, temporarilyClosed: false, notes: "", lastVerified: "2026-10-10", status: "Verified" },
];

export const demoCategories: PartnerCategory[] = [
  { id: "cat-lamps", orgId: "pretty-good", category: "Lamps", status: "Accepted", functional: true, minorCosmetic: true, missingParts: false, severeDamage: false, notes: "Final acceptance depends on inspection at the collection point.", lastVerified: "2026-10-18", verificationStatus: "Verified" },
  { id: "cat-furniture", orgId: "pretty-good", category: "Small furniture", status: "Accepted", functional: true, minorCosmetic: true, missingParts: false, severeDamage: false, notes: "", lastVerified: "2026-10-18", verificationStatus: "Verified" },
  { id: "cat-appliances", orgId: "pretty-good", category: "Household appliances", status: "Accepted", functional: true, minorCosmetic: true, missingParts: false, severeDamage: false, notes: "", lastVerified: "2026-10-18", verificationStatus: "Verified" },
  { id: "cat-electronics", orgId: "pretty-good", category: "Consumer electronics", status: "Conditionally accepted", functional: true, minorCosmetic: false, missingParts: false, severeDamage: false, notes: "Only working devices with cables.", lastVerified: "2026-09-01", verificationStatus: "Needs review" },
  { id: "cat-tools", orgId: "pretty-good", category: "Tools", status: "Accepted", functional: true, minorCosmetic: true, missingParts: false, severeDamage: false, notes: "", lastVerified: "2026-10-18", verificationStatus: "Verified" },
  { id: "cat-music", orgId: "pretty-good", category: "Musical instruments", status: "Conditionally accepted", functional: true, minorCosmetic: true, missingParts: false, severeDamage: false, notes: "", lastVerified: "2026-08-14", verificationStatus: "Verified" },
  { id: "cat-toys", orgId: "pretty-good", category: "Toys", status: "Accepted", functional: true, minorCosmetic: true, missingParts: false, severeDamage: false, notes: "Complete sets only.", lastVerified: "2026-10-18", verificationStatus: "Verified" },
  { id: "cat-sports", orgId: "pretty-good", category: "Sports equipment", status: "Accepted", functional: true, minorCosmetic: true, missingParts: false, severeDamage: false, notes: "", lastVerified: "2026-10-18", verificationStatus: "Verified" },
  { id: "cat-antiques", orgId: "pretty-good", category: "Antiques and decorative objects", status: "Conditionally accepted", functional: true, minorCosmetic: true, missingParts: false, severeDamage: false, notes: "", lastVerified: "2026-07-20", verificationStatus: "Verified" },
  { id: "cat-textiles", orgId: "pretty-good", category: "Textiles", status: "Not accepted", functional: false, minorCosmetic: false, missingParts: false, severeDamage: false, notes: "Use textile collection points instead.", lastVerified: "2026-10-18", verificationStatus: "Verified" },
  { id: "bs-cat-electrical", orgId: "bs-recycling", category: "Electrical appliances", status: "Accepted", functional: false, minorCosmetic: false, missingParts: true, severeDamage: true, notes: "All states accepted for material recovery.", lastVerified: "2026-10-10", verificationStatus: "Verified" },
  { id: "bs-cat-metals", orgId: "bs-recycling", category: "Metals", status: "Accepted", functional: false, minorCosmetic: false, missingParts: true, severeDamage: true, notes: "", lastVerified: "2026-10-10", verificationStatus: "Verified" },
  { id: "bs-cat-glass", orgId: "bs-recycling", category: "Glass", status: "Accepted", functional: false, minorCosmetic: false, missingParts: true, severeDamage: true, notes: "", lastVerified: "2026-10-10", verificationStatus: "Verified" },
  { id: "bs-cat-textiles", orgId: "bs-recycling", category: "Textiles", status: "Conditionally accepted", functional: true, minorCosmetic: true, missingParts: false, severeDamage: false, notes: "Clean and dry only.", lastVerified: "2026-10-10", verificationStatus: "Verified" },
  { id: "bs-cat-furniture", orgId: "bs-recycling", category: "Furniture", status: "Not accepted", functional: false, minorCosmetic: false, missingParts: false, severeDamage: false, notes: "Reusable furniture goes to Pretty Good.", lastVerified: "2026-10-10", verificationStatus: "Verified" },
  { id: "bs-cat-paper", orgId: "bs-recycling", category: "Paper and cardboard", status: "Accepted", functional: false, minorCosmetic: false, missingParts: true, severeDamage: true, notes: "", lastVerified: "2026-10-10", verificationStatus: "Verified" },
  { id: "bs-cat-batteries", orgId: "bs-recycling", category: "Batteries", status: "Accepted", functional: false, minorCosmetic: false, missingParts: true, severeDamage: true, notes: "", lastVerified: "2026-10-10", verificationStatus: "Verified" },
  { id: "bs-cat-green", orgId: "bs-recycling", category: "Green waste", status: "Accepted", functional: false, minorCosmetic: false, missingParts: true, severeDamage: true, notes: "", lastVerified: "2026-08-30", verificationStatus: "Verified" },
];

export const demoRules: RoutingRule[] = [
  { id: "rule-lamp", orgId: "pretty-good", code: "PG-LAMP-004", category: "Lamps", condition: "Functional", damageSeverity: "Minor", recommend: "Pretty Good Basel", confidenceModifier: 20, alternative: "Repair / Donate", status: "Verified", lastVerified: "2026-10-18" },
  { id: "rule-furniture", orgId: "pretty-good", code: "PG-FURN-002", category: "Small furniture", condition: "Functional", damageSeverity: "Minor", recommend: "Pretty Good Basel", confidenceModifier: 15, alternative: "Donate", status: "Verified", lastVerified: "2026-10-18" },
  { id: "rule-electronics", orgId: "pretty-good", code: "PG-ELEC-007", category: "Consumer electronics", condition: "Functional", damageSeverity: "None", recommend: "Pretty Good Basel", confidenceModifier: 10, alternative: "Repair", status: "Needs review", lastVerified: "2026-09-01" },
  { id: "rule-toys", orgId: "pretty-good", code: "PG-TOYS-003", category: "Toys", condition: "Functional", damageSeverity: "Minor", recommend: "Pretty Good Basel", confidenceModifier: 10, alternative: "Donate", status: "Verified", lastVerified: "2026-10-18" },
  { id: "bs-rule-electrical", orgId: "bs-recycling", code: "BS-ELEC-001", category: "Electrical appliances", condition: "Any", damageSeverity: "Any", recommend: "Recycling point", confidenceModifier: 25, alternative: "Pretty Good if working", status: "Verified", lastVerified: "2026-10-10" },
  { id: "bs-rule-metals", orgId: "bs-recycling", code: "BS-MET-002", category: "Metals", condition: "Any", damageSeverity: "Any", recommend: "Recycling point", confidenceModifier: 25, alternative: "None", status: "Verified", lastVerified: "2026-10-10" },
];

export const demoReports: UserReport[] = [
  { id: "rep-1", orgId: "pretty-good", type: "Opening hours", target: "Lottner AG", date: "2026-10-21", comment: "Opening hours appear incorrect.", currentData: "Mon to Fri, 8 to 17", status: "Open" },
  { id: "rep-2", orgId: "pretty-good", type: "Item eligibility", target: "Werkhof / Recyclingpark Riehen", date: "2026-10-19", comment: "Location did not accept my item.", currentData: "Small furniture: Accepted", status: "Open" },
  { id: "rep-3", orgId: "pretty-good", type: "Address", target: "Mobile collection Aeschenplatz", date: "2026-10-12", comment: "Address appears outdated.", currentData: "Aeschenplatz, Basel", status: "Resolved" },
  { id: "rep-4", orgId: "bs-recycling", type: "Service no longer available", target: "Recyclinghof Breite", date: "2026-09-30", comment: "Service no longer available.", currentData: "Green waste container", status: "Confirmed" },
];

export const demoHistory: HistoryEvent[] = [
  { id: "hist-1", orgId: "pretty-good", date: "2026-10-18", user: "Anna Keller — Pretty Good Basel", change: "Small furniture", oldValue: "Conditionally accepted", newValue: "Accepted" },
  { id: "hist-2", orgId: "pretty-good", date: "2026-10-18", user: "Anna Keller — Pretty Good Basel", change: "Rule PG-LAMP-004", oldValue: "Needs review", newValue: "Verified" },
  { id: "hist-3", orgId: "pretty-good", date: "2026-10-03", user: "Marco Brunner — Pretty Good Basel", change: "Opening hours Werkhof / Recyclingpark Riehen", oldValue: "Mon to Fri, 8 to 16", newValue: "Mon to Sat, 8 to 16" },
  { id: "hist-4", orgId: "bs-recycling", date: "2026-10-10", user: "Laura Frei — Basel-Stadt Recycling", change: "Recyclinghof Breite", oldValue: "Needs review", newValue: "Verified" },
  { id: "hist-5", orgId: "bs-recycling", date: "2026-09-15", user: "Laura Frei — Basel-Stadt Recycling", change: "Textiles", oldValue: "Accepted", newValue: "Conditionally accepted" },
];

export const partnerRoleDescriptions: Record<PartnerRole, string> = {
  Admin: "Can edit everything.",
  Editor: "Can edit locations and rules.",
  Verifier: "Can confirm information but cannot change organization settings.",
  Viewer: "Can only view data and reports.",
};
