import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { OptionBrowser, OptionNotice } from "@/components/OptionBrowser";
import { actionLabels, itemLabels } from "@/data/labels";
import { directoryLabels, directoryItemLabels } from "@/data/directory-labels";
import { useT } from "@/lib/i18n";
import type { ActionType, DirectoryCategory, DirectoryItem, ItemCategory } from "@/data/types";
import type { OptionFilters } from "@/lib/option-filter";

export const Route = createFileRoute("/explore")({
  validateSearch: (s: Record<string, unknown>): OptionFilters & { recommended?: ActionType | undefined } => ({
    q: typeof s["q"] === "string" && s["q"] ? s["q"] : undefined,
    action: Object.keys(actionLabels).includes(String(s["action"])) ? s["action"] as ActionType : undefined,
    item: Object.keys(itemLabels).includes(String(s["item"])) ? s["item"] as ItemCategory : undefined,
    category: Object.keys(directoryLabels).includes(String(s["category"])) ? s["category"] as DirectoryCategory : undefined,
    directoryItem: Object.keys(directoryItemLabels).includes(String(s["directoryItem"])) ? s["directoryItem"] as DirectoryItem : undefined,
    free: s["free"] === true || undefined,
    appointmentRequired: s["appointmentRequired"] === true || undefined,
    acceptsDamaged: s["acceptsDamaged"] === true || undefined,
    pickupAvailable: s["pickupAvailable"] === true || undefined,
    recommended: Object.keys(actionLabels).includes(String(s["recommended"])) ? s["recommended"] as ActionType : undefined,
  }),
  head: () => ({ meta: [
    { title: "Circular economy directory — Wiiter" },
    { name: "description", content: "Find repair shops, donation points, reuse initiatives, collection points and recycling options around Basel." },
    { property: "og:title", content: "Basel circular economy directory — Wiiter" },
    { property: "og:description", content: "Search local ways to repair, donate, reuse and recycle your item." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: Explore,
});
function Explore() {
  const t = useT();
  const filters = Route.useSearch();
  const navigate = useNavigate({ from: "/explore" });
  return <div className="container-page pt-14">
    <p className="eyebrow">{t("Circular economy directory")}</p>
    <h1 className="mt-3 max-w-3xl text-4xl font-semibold leading-tight">{t("Find the right place for your item")}</h1>
    <p className="mt-4 max-w-2xl text-lg text-muted-foreground">{t("Discover repair shops, donation points, recycling facilities and reuse initiatives around Basel.")}</p>
    <OptionNotice />
    <OptionBrowser filters={filters} recommendedAction={filters.recommended} onChange={(search) => { void navigate({ search: { ...search, recommended: filters.recommended }, replace: true }); }} />
  </div>;
}
