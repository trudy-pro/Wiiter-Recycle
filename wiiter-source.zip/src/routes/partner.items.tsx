import { createFileRoute } from "@tanstack/react-router";
import { BadgeCheck } from "lucide-react";
import { useLanguage, useT } from "@/lib/i18n";
import { canEdit, canVerify, partnerActions, usePartnerState } from "@/lib/partner-store";
import { formatVerifiedDate } from "@/lib/sources";
import { StatusBadge } from "@/components/partner-ui";
import type { CategoryStatus } from "@/data/partner";

export const Route = createFileRoute("/partner/items")({ component: PartnerItems });

const statuses: CategoryStatus[] = ["Accepted", "Conditionally accepted", "Not accepted"];

function PartnerItems() {
  const t = useT();
  const { lang } = useLanguage();
  const { orgId, role, categories } = usePartnerState();
  const mine = categories.filter((c) => c.orgId === orgId);

  return <div>
    <h2 className="text-2xl font-semibold">{t("Accepted items")}</h2>
    <p className="mt-2 text-sm text-muted-foreground">{t("Which categories you accept, and in which condition.")}</p>
    <ul className="mt-6 grid gap-3">
      {mine.map((cat) => <li key={cat.id} className="rounded-xl border border-border p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h3 className="font-semibold">{t(cat.category)}</h3>
          <div className="flex items-center gap-2">
            <StatusBadge status={cat.verificationStatus} />
            {canEdit(role) ? <select value={cat.status} onChange={(e) => partnerActions.updateCategory(cat.id, { status: e.target.value as CategoryStatus })} className="rounded-full border border-input bg-background px-3 py-1.5 text-sm" aria-label={t("Status")}>
              {statuses.map((s) => <option key={s} value={s}>{t(s)}</option>)}
            </select> : <span className="text-sm font-medium">{t(cat.status)}</span>}
          </div>
        </div>
        <dl className="mt-3 grid grid-cols-2 gap-2 text-sm sm:grid-cols-4">
          {([
            ["Functional", cat.functional],
            ["Minor cosmetic damage", cat.minorCosmetic],
            ["Missing parts", cat.missingParts],
            ["Severe structural damage", cat.severeDamage],
          ] as const).map(([label, value]) => <div key={label} className="rounded-lg bg-muted/60 px-3 py-2">
            <dt className="text-xs text-muted-foreground">{t(label)}</dt>
            <dd className="font-medium">{t(value ? "Yes" : "No")}</dd>
          </div>)}
        </dl>
        {cat.notes && <p className="mt-2 text-sm text-muted-foreground">{t(cat.notes)}</p>}
        <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
          <p className="text-xs text-muted-foreground">{t("Last verified")}: {formatVerifiedDate(cat.lastVerified, lang)}</p>
          {canVerify(role) && <button type="button" onClick={() => partnerActions.verifyCategory(cat.id)} className="inline-flex items-center gap-1.5 text-sm font-medium underline-offset-4 hover:underline">
            <BadgeCheck className="h-4 w-4" aria-hidden />{t("Verify information")}
          </button>}
        </div>
      </li>)}
    </ul>
  </div>;
}
