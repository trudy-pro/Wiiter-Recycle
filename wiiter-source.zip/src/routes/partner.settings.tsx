import { createFileRoute } from "@tanstack/react-router";
import { useT } from "@/lib/i18n";
import { partnerOrgs } from "@/data/partner";
import { canManageSettings, partnerActions, usePartnerState } from "@/lib/partner-store";

export const Route = createFileRoute("/partner/settings")({ component: PartnerSettings });

function PartnerSettings() {
  const t = useT();
  const { orgId, role } = usePartnerState();
  const org = partnerOrgs.find((o) => o.id === orgId);

  if (!canManageSettings(role)) {
    return <div className="rounded-xl border border-border p-6">
      <h2 className="text-xl font-semibold">{t("Organization settings")}</h2>
      <p className="mt-2 text-sm text-muted-foreground">{t("Only admins can change organization settings. Switch the role above to Admin to explore this page.")}</p>
    </div>;
  }

  return <div>
    <h2 className="text-2xl font-semibold">{t("Organization settings")}</h2>
    <div className="mt-6 grid gap-3">
      <div className="rounded-xl border border-border p-5">
        <h3 className="font-semibold">{t("Organization")}</h3>
        <p className="mt-1 text-sm text-muted-foreground">{org?.name}</p>
        <p className="mt-1 text-sm text-muted-foreground">{t("Verification thresholds")}: 30 / 90 {t("days")}</p>
      </div>
      <div className="rounded-xl border border-border p-5">
        <h3 className="font-semibold">{t("Demo data")}</h3>
        <p className="mt-1 text-sm text-muted-foreground">{t("Reset all locations, rules, reports and history to the demo state.")}</p>
        <button type="button" onClick={() => partnerActions.resetDemo()} className="btn btn-outline mt-3 !px-4 !py-2 text-sm">{t("Reset demo data")}</button>
      </div>
    </div>
  </div>;
}
