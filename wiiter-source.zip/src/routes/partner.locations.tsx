import { createFileRoute } from "@tanstack/react-router";
import { BadgeCheck, MapPin } from "lucide-react";
import { useLanguage, useT } from "@/lib/i18n";
import { canEdit, canVerify, partnerActions, usePartnerState } from "@/lib/partner-store";
import { formatVerifiedDate } from "@/lib/sources";
import { StatusBadge } from "@/components/partner-ui";

export const Route = createFileRoute("/partner/locations")({ component: PartnerLocations });

function PartnerLocations() {
  const t = useT();
  const { lang } = useLanguage();
  const { orgId, role, locations } = usePartnerState();
  const mine = locations.filter((l) => l.orgId === orgId);

  return <div>
    <h2 className="text-2xl font-semibold">{t("Locations")}</h2>
    <p className="mt-2 text-sm text-muted-foreground">{t("Keep addresses, opening hours and closures up to date.")}</p>
    <ul className="mt-6 grid gap-3">
      {mine.map((loc) => <li key={loc.id} className="rounded-xl border border-border p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="flex items-start gap-3">
            <MapPin className="mt-0.5 h-5 w-5 shrink-0 text-directory-icon" aria-hidden />
            <div>
              <h3 className="font-semibold">{loc.name}</h3>
              <p className="text-sm text-muted-foreground">{t(loc.address)}</p>
              <p className="mt-1 text-sm">{t(loc.hours)}{loc.phone ? ` · ${loc.phone}` : ""}</p>
              {loc.notes && <p className="mt-1 text-sm text-muted-foreground">{t(loc.notes)}</p>}
              <p className="mt-2 text-xs text-muted-foreground">{t("Last verified")}: {formatVerifiedDate(loc.lastVerified, lang)}</p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <StatusBadge status={loc.status} />
            {loc.temporarilyClosed && <span className="rounded-full bg-warning px-2.5 py-0.5 text-xs font-semibold text-warning-foreground">{t("Temporarily closed")}</span>}
            {!loc.active && <span className="rounded-full bg-muted px-2.5 py-0.5 text-xs font-semibold text-muted-foreground">{t("Inactive")}</span>}
          </div>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          {canVerify(role) && <button type="button" onClick={() => partnerActions.verifyLocation(loc.id)} className="btn btn-outline !px-4 !py-2 text-sm">
            <BadgeCheck className="h-4 w-4" aria-hidden />{t("Verified today")}
          </button>}
          {canEdit(role) && <>
            <button type="button" onClick={() => partnerActions.updateLocation(loc.id, { temporarilyClosed: !loc.temporarilyClosed }, `${loc.name}: closure`)} className="btn btn-outline !px-4 !py-2 text-sm">
              {loc.temporarilyClosed ? t("Reopen location") : t("Mark temporarily closed")}
            </button>
            <button type="button" onClick={() => partnerActions.updateLocation(loc.id, { active: !loc.active }, `${loc.name}: status`)} className="btn btn-outline !px-4 !py-2 text-sm">
              {loc.active ? t("Deactivate") : t("Activate")}
            </button>
          </>}
        </div>
      </li>)}
    </ul>
  </div>;
}
