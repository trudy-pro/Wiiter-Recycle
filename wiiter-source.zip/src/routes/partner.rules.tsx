import { createFileRoute } from "@tanstack/react-router";
import { ArrowRight, BadgeCheck } from "lucide-react";
import { useLanguage, useT } from "@/lib/i18n";
import { canEdit, canVerify, partnerActions, usePartnerState } from "@/lib/partner-store";
import { formatVerifiedDate } from "@/lib/sources";
import { StatusBadge } from "@/components/partner-ui";
import type { VerificationStatus } from "@/data/partner";

export const Route = createFileRoute("/partner/rules")({ component: PartnerRules });

const ruleStatuses: VerificationStatus[] = ["Verified", "Needs review", "Outdated", "Draft"];

function PartnerRules() {
  const t = useT();
  const { lang } = useLanguage();
  const { orgId, role, rules } = usePartnerState();
  const mine = rules.filter((r) => r.orgId === orgId);

  return <div>
    <h2 className="text-2xl font-semibold">{t("Routing rules")}</h2>
    <p className="mt-2 text-sm text-muted-foreground">{t("The rules Wiiter uses for recommendations. Editable without code.")}</p>
    <ul className="mt-6 grid gap-3">
      {mine.map((rule) => <li key={rule.id} className="rounded-xl border border-border p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <span className="rounded-full bg-muted px-2.5 py-0.5 text-xs font-semibold">{rule.code}</span>
          <div className="flex items-center gap-2">
            <StatusBadge status={rule.status} />
            {canEdit(role) && <select value={rule.status} onChange={(e) => partnerActions.updateRule(rule.id, { status: e.target.value as VerificationStatus })} className="rounded-full border border-input bg-background px-3 py-1.5 text-sm" aria-label={t("Status")}>
              {ruleStatuses.map((s) => <option key={s} value={s}>{t(s)}</option>)}
            </select>}
          </div>
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-x-2 gap-y-1 text-sm">
          <span className="font-semibold">{t("IF")}</span>
          <span className="rounded-full bg-muted px-2.5 py-1">{t("Category")} = {t(rule.category)}</span>
          <span className="font-semibold">{t("AND")}</span>
          <span className="rounded-full bg-muted px-2.5 py-1">{t("Condition")} = {t(rule.condition)}</span>
          <span className="font-semibold">{t("AND")}</span>
          <span className="rounded-full bg-muted px-2.5 py-1">{t("Damage severity")} = {t(rule.damageSeverity)}</span>
        </div>
        <div className="mt-2 flex flex-wrap items-center gap-x-2 gap-y-1 text-sm">
          <span className="font-semibold">{t("THEN")}</span>
          <ArrowRight className="h-4 w-4 text-directory-icon" aria-hidden />
          <span className="rounded-full bg-accent px-2.5 py-1 font-medium text-accent-foreground">{t("Recommend")} {rule.recommend}</span>
          <span className="rounded-full bg-muted px-2.5 py-1">{t("Confidence modifier")}: +{rule.confidenceModifier}%</span>
          <span className="rounded-full bg-muted px-2.5 py-1">{t("Alternative")}: {rule.alternative}</span>
        </div>
        <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
          <p className="text-xs text-muted-foreground">{t("Last verified")}: {formatVerifiedDate(rule.lastVerified, lang)}</p>
          {canVerify(role) && <button type="button" onClick={() => partnerActions.verifyRule(rule.id)} className="inline-flex items-center gap-1.5 text-sm font-medium underline-offset-4 hover:underline">
            <BadgeCheck className="h-4 w-4" aria-hidden />{t("Verify information")}
          </button>}
        </div>
      </li>)}
    </ul>
  </div>;
}
