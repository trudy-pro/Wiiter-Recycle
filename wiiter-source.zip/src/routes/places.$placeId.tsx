import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowLeft, ArrowUpRight, Bookmark, Check, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { options } from "@/data/options";
import { optionImages } from "@/data/option-images";
import { directoryItemLabels } from "@/data/directory-labels";
import { itemLabels } from "@/data/labels";
import { useT } from "@/lib/i18n";

export const Route = createFileRoute("/places/$placeId")({
  loader: ({ params }) => {
    const place = options.find((entry) => entry.id === params.placeId);
    if (!place) throw notFound();
    return place;
  },
  head: ({ loaderData }) => ({ meta: [
    { title: `${loaderData?.title ?? "Place"} — Wiiter` },
    { name: "description", content: loaderData?.description ?? "Circular economy place details in Basel." },
    { property: "og:title", content: `${loaderData?.title ?? "Place"} — Wiiter` },
    { property: "og:description", content: loaderData?.description ?? "Find your item's next use in Basel." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: PlaceDetails,
});

function PlaceDetails() {
  const place = Route.useLoaderData();
  const t = useT();
  const [saved, setSaved] = useState(false);
  return <div className="container-page max-w-4xl pt-10">
    <Button asChild variant="ghost" className="px-0"><Link to="/explore"><ArrowLeft />{t("Back to directory")}</Link></Button>
    <div className="mt-8 flex flex-wrap gap-2 text-xs"><span className="rounded-full bg-accent px-3 py-1 text-accent-foreground">{t(place.verificationStatus === "example" ? "Example" : place.verificationStatus === "verified" ? "Verified" : place.verificationStatus === "community" ? "Community submitted" : "Official source")}</span>{place.checkedAt && <span className="rounded-full bg-muted px-3 py-1">{t("Source checked")}: {place.checkedAt}</span>}</div>
    <h1 className="mt-4 text-3xl font-semibold leading-tight md:text-4xl">{t(place.title)}</h1>
    <p className="mt-4 max-w-2xl text-lg text-muted-foreground">{t(place.description)}</p>
    {optionImages[place.id] && <figure className="mt-7"><img src={optionImages[place.id]} alt={t(place.title)} className="aspect-[3/1] w-full rounded-lg object-cover" /><figcaption className="mt-2 text-xs text-muted-foreground">{t("Illustrative photo, not a photograph of this provider.")}</figcaption></figure>}
    <div className="mt-8 grid gap-x-10 gap-y-7 border-t py-8 sm:grid-cols-2">
      <section><h2 className="font-semibold">{t("Good for")}</h2><div className="mt-3 flex flex-wrap gap-2">{(place.directoryItems?.map((i) => directoryItemLabels[i]) ?? place.itemCategory.map((i) => itemLabels[i])).map((label) => <span key={label} className="rounded-full bg-muted px-3 py-1 text-sm">{t(label)}</span>)}</div></section>
      <section><h2 className="font-semibold">{t("Services")}</h2><p className="mt-3 text-sm text-muted-foreground">{t(place.eligibilityNotes)}</p></section>
      <section><h2 className="font-semibold">{t("Cost")}</h2><p className="mt-3 text-sm text-muted-foreground">{t(place.cost ?? "Contact provider")}</p></section>
      <section><h2 className="font-semibold">{t("When")}</h2><p className="mt-3 text-sm text-muted-foreground">{t(place.hours ?? "Hours not yet verified")}</p></section>
      <section><h2 className="font-semibold">{t("Where")}</h2><p className="mt-3 text-sm text-muted-foreground">{t(place.address ?? place.location ?? "Location not yet verified")}</p></section>
      <section><h2 className="font-semibold">{t("Before you go")}</h2><ul className="mt-3 space-y-2 text-sm text-muted-foreground">{place.nextSteps.map((step) => <li key={step} className="flex gap-2"><Check className="mt-0.5 h-4 w-4 shrink-0" />{t(step)}</li>)}<li>{t("Check with provider before visiting")}</li></ul></section>
    </div>
    <p className="border-t pt-5 text-sm text-muted-foreground">{t(place.verificationStatus === "example" ? "This is an illustrative example, not a verified local provider." : place.verificationStatus === "community" ? "Community submitted information has not yet been verified." : "The linked official source describes this service. Hours and acceptance conditions can change.")}</p>
    <div className="mt-6 flex flex-wrap gap-3">
      {place.address && <Button asChild className="btn btn-primary h-auto whitespace-normal"><a href={`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(place.address)}`} target="_blank" rel="noreferrer">{t("Get directions")}<ArrowUpRight /></a></Button>}
      {place.sourceUrl && <Button asChild variant="outline" className="btn btn-outline h-auto whitespace-normal"><a href={place.sourceUrl} target="_blank" rel="noreferrer">{t("Visit website")}<ArrowUpRight /></a></Button>}
      {place.phone && <Button asChild variant="outline"><a href={`tel:${place.phone}`}><Phone />{t("Call")}</a></Button>}
      <Button variant="outline" aria-pressed={saved} onClick={() => setSaved(!saved)}><Bookmark />{t(saved ? "Saved for this visit" : "Save for this visit")}</Button>
    </div>
  </div>;
}