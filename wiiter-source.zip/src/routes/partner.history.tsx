import { createFileRoute } from "@tanstack/react-router";
import { useLanguage, useT } from "@/lib/i18n";
import { usePartnerState } from "@/lib/partner-store";
import { formatVerifiedDate } from "@/lib/sources";

export const Route = createFileRoute("/partner/history")({ component: PartnerHistory });

function PartnerHistory() {
  const t = useT();
  const { lang } = useLanguage();
  const { orgId, history } = usePartnerState();
  const mine = history.filter((h) => h.orgId === orgId);

  return <div>
    <h2 className="text-2xl font-semibold">{t("Verification history")}</h2>
    <p className="mt-2 text-sm text-muted-foreground">{t("Every change and verification, in order.")}</p>
    <ol className="mt-6 space-y-0">
      {mine.map((event) => <li key={event.id} className="relative border-l-2 border-border pb-6 pl-6 last:pb-0">
        <span className="absolute -left-[5px] top-1.5 h-2 w-2 rounded-full bg-lime" aria-hidden />
        <p className="text-sm text-muted-foreground">{formatVerifiedDate(event.date, lang)}</p>
        <p className="mt-1 font-semibold">{event.user}</p>
        <p className="mt-1 text-sm">{t("Changed")}: {event.change}</p>
        <p className="mt-1 text-sm">
          <span className="text-muted-foreground">{t("from")}: </span><span className="rounded bg-muted px-1.5 py-0.5">{t(event.oldValue)}</span>
          <span className="mx-2 text-muted-foreground">{t("to")}:</span><span className="rounded bg-accent px-1.5 py-0.5 text-accent-foreground">{t(event.newValue)}</span>
        </p>
      </li>)}
    </ol>
  </div>;
}
