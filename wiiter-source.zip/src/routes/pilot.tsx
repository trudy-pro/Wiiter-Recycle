import { createFileRoute } from "@tanstack/react-router";
import { useT } from "@/lib/i18n";
import { getPilotEvents } from "@/lib/pilot";

export const Route = createFileRoute("/pilot")({
  head: () => ({
    meta: [
      { title: "Pilot dashboard — Wiiter" },
      { name: "description", content: "Demo pilot metrics for the Wiiter and Pretty Good Basel routing prototype." },
      { property: "og:title", content: "Pilot dashboard — Wiiter" },
      { property: "og:description", content: "How the Wiiter pilot routes items to reuse, repair, donation and recycling." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PilotDashboard,
});

/** Mock figures for partnership demos. Replace with live pilot data later. */
const mock = {
  totalAnalyzed: 312,
  prettyGoodPct: 41,
  repairPct: 24,
  donatePct: 19,
  recyclePct: 16,
  acceptancePct: 87,
  feedbackPct: 78,
  topCategories: [
    { label: "Lamps", count: 64 },
    { label: "Small furniture", count: 52 },
    { label: "Household appliances", count: 47 },
    { label: "Tools", count: 38 },
    { label: "Toys", count: 26 },
  ],
};

function PilotDashboard() {
  const t = useT();
  const localEvents = getPilotEvents().length;
  const stats = [
    { label: "Items analyzed", value: String(mock.totalAnalyzed) },
    { label: "Routed to Pretty Good", value: `${mock.prettyGoodPct}%` },
    { label: "Routed to repair", value: `${mock.repairPct}%` },
    { label: "Routed to donation", value: `${mock.donatePct}%` },
    { label: "Routed to recycling", value: `${mock.recyclePct}%` },
    { label: "Pretty Good acceptance rate", value: `${mock.acceptancePct}%` },
    { label: "User feedback score", value: `${mock.feedbackPct}%` },
  ];
  const maxCategory = Math.max(...mock.topCategories.map((c) => c.count));

  return <div className="container-page max-w-4xl pt-10 md:pt-14">
    <p className="eyebrow">{t("Pilot dashboard")}</p>
    <h1 className="mt-3 text-3xl font-semibold leading-tight md:text-4xl">{t("Wiiter x Pretty Good Basel pilot")}</h1>
    <p className="mt-3 max-w-2xl text-muted-foreground">{t("Demo data for partnership meetings. Live figures appear here once the pilot is running.")}</p>

    <dl className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
      {stats.map((s) => <div key={s.label} className="rounded-xl border border-border p-5">
        <dt className="text-sm text-muted-foreground">{t(s.label)}</dt>
        <dd className="mt-2 text-3xl font-semibold">{s.value}</dd>
      </div>)}
    </dl>

    <section className="mt-10" aria-labelledby="pilot-categories">
      <h2 id="pilot-categories" className="text-lg font-semibold">{t("Top item categories")}</h2>
      <ul className="mt-4 space-y-3">
        {mock.topCategories.map((c) => <li key={c.label}>
          <div className="flex items-center justify-between gap-3 text-sm">
            <span className="font-medium">{t(c.label)}</span>
            <span className="text-muted-foreground">{c.count}</span>
          </div>
          <div className="mt-1 h-2 overflow-hidden rounded-full bg-muted">
            <div className="h-full rounded-full bg-lime" style={{ width: `${Math.round((c.count / maxCategory) * 100)}%` }} />
          </div>
        </li>)}
      </ul>
    </section>

    <section className="mt-10" aria-labelledby="pilot-trust">
      <h2 id="pilot-trust" className="text-lg font-semibold">{t("Trust and data quality")}</h2>
      <dl className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {([
          ["Recommendations with official sources", "92%"],
          ["Average source age", "24 days"],
          ["Sources verified in the last 30 days", "96%"],
          ["Outdated information reports", "3"],
        ] as const).map(([label, value]) => <div key={label} className="rounded-xl border border-border p-5">
          <dt className="text-sm text-muted-foreground">{t(label)}</dt>
          <dd className="mt-2 text-2xl font-semibold">{t(value)}</dd>
        </div>)}
      </dl>
    </section>

    <section className="mt-10" aria-labelledby="pilot-outcomes">
      <h2 id="pilot-outcomes" className="text-lg font-semibold">{t("Outcome quality")}</h2>
      <dl className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {([
          ["Users who reported an outcome", "64%"],
          ["Recommendation acceptance rate", "71%"],
          ["Destination acceptance rate", "87%"],
          ["Recommendation accuracy", "78%"],
          ["Most common rejection reason", "Too damaged"],
        ] as const).map(([label, value]) => <div key={label} className="rounded-xl border border-border p-5">
          <dt className="text-sm text-muted-foreground">{t(label)}</dt>
          <dd className="mt-2 text-2xl font-semibold">{t(value)}</dd>
        </div>)}
      </dl>
    </section>

    <section className="mt-10" aria-labelledby="pilot-funnel">
      <h2 id="pilot-funnel" className="text-lg font-semibold">{t("Routing effectiveness")}</h2>
      <ol className="mt-4 grid gap-3 sm:grid-cols-5">
        {([
          ["Analyzed", 312],
          ["Recommended", 298],
          ["Destination selected", 201],
          ["Outcome reported", 142],
          ["Reused, repaired or recycled", 118],
        ] as const).map(([label, value], i, arr) => <li key={label} className="rounded-xl bg-muted/60 p-4">
          <p className="text-2xl font-semibold">{value}</p>
          <p className="mt-1 text-sm text-muted-foreground">{t(label)}</p>
          <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-muted">
            <div className="h-full rounded-full bg-lime" style={{ width: `${Math.round((value / arr[0]![1]) * 100)}%` }} />
          </div>
          {i > 0 && <p className="mt-1 text-xs text-muted-foreground">{Math.round((value / arr[i - 1]![1]) * 100)}% {t("of previous step")}</p>}
        </li>)}
      </ol>
    </section>

    <section className="mt-10" aria-labelledby="pilot-partners">
      <h2 id="pilot-partners" className="text-lg font-semibold">{t("Partner participation")}</h2>
      <dl className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {([
          ["Active partner organizations", "2"],
          ["Recommendations using partner verified data", "68%"],
          ["Average verification age", "19 days"],
          ["Reports resolved", "14"],
          ["Data corrections made", "9"],
          ["Most frequently updated rule", "PG-LAMP-004"],
        ] as const).map(([label, value]) => <div key={label} className="rounded-xl border border-border p-5">
          <dt className="text-sm text-muted-foreground">{t(label)}</dt>
          <dd className="mt-2 text-2xl font-semibold">{t(value)}</dd>
        </div>)}
      </dl>
    </section>

    <p className="mt-10 rounded-xl bg-muted/60 px-4 py-3 text-sm text-muted-foreground">
      {t("Events recorded on this device")}: {localEvents}
    </p>

    <section className="mt-10 rounded-2xl bg-foreground p-6 text-background md:p-8" aria-labelledby="pilot-partnership">
      <h2 id="pilot-partnership" className="text-lg font-semibold">{t("How Wiiter fits in")}</h2>
      <p className="mt-3 opacity-80">{t("Wiiter complements existing reuse infrastructure. It helps residents identify the right next step before travelling to a collection point.")}</p>
      <p className="mt-3 opacity-80">{t("Wiiter does not only recommend where an item should go. It shows the source behind the recommendation, when the information was last verified, and whether the recommendation worked in practice.")}</p>
      <p className="mt-2 text-sm opacity-60">{t("Digital pre sorting and routing, not a replacement for Pretty Good Basel.")}</p>
    </section>
  </div>;
}
