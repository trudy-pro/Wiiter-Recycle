import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { ActionIcon } from "@/components/ActionIcon";
import { useT } from "@/lib/i18n";
import type { ActionType } from "@/data/types";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Wiiter — find your item's next use" },
      { name: "description", content: "Before you throw it away, find a practical next step to repair, give away, reuse or recycle your item in Basel." },
      { property: "og:title", content: "Wiiter" },
      { property: "og:description", content: "Find a practical next step for unwanted and broken objects in Basel." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const categories: { action: ActionType; title: string; text: string }[] = [
  { action: "repair", title: "Repair", text: "Fix what is broken or worn and keep using it." },
  { action: "donate", title: "Give Away", text: "Let working items find someone who needs them." },
  { action: "resell", title: "Reuse / Resell", text: "Pass things on, or reuse them in a new way." },
  { action: "recycle", title: "Recycle", text: "Recover materials when nothing else fits." },
];

const steps = [
  { n: "01", t: "Describe it", d: "Tell us what the item is and its condition." },
  { n: "02", t: "Find your option", d: "See the best next step and relevant places." },
  { n: "03", t: "Give it a second chance", d: "Repair, reuse, sell, donate or recycle." },
];

function Index() {
  const t = useT();
  return (
    <>
      <section className="container-page pt-16 pb-20 text-center md:pt-28 md:pb-28 fade-up">
        <p className="eyebrow">{t("A civic guide for Basel residents")}</p>
        <h1 className="mx-auto mt-5 max-w-4xl text-4xl font-semibold leading-[1.05] tracking-tight md:text-7xl">
          {t("What to do with your old stuff")}
        </h1>
        <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground">
          {t("Tell us about an unwanted or broken object and get a practical next step: repair, give away, reuse or recycle, with the reasons behind it.")}
        </p>
        <div className="mt-10 flex flex-wrap justify-center gap-3">
          <Link to="/assess" className="btn btn-primary">
            {t("Find my next step")} <ArrowRight className="h-4 w-4" aria-hidden />
          </Link>
          <Link to="/explore" className="btn btn-outline">{t("Directory")}</Link>
        </div>
      </section>

      <section className="container-page" aria-labelledby="cat">
        <h2 id="cat" className="eyebrow">{t("Four routes to a second chance")}</h2>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {categories.map((c) => (
            <Link
              key={c.title}
              to="/explore"
              search={{ action: c.action }}
              className="card-civic group p-6 transition-colors hover:border-primary"
            >
              <span className="grid h-10 w-10 place-items-center rounded-full bg-accent text-accent-foreground">
                <ActionIcon action={c.action} />
              </span>
              <h3 className="mt-6 text-lg font-semibold">{t(c.title)}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{t(c.text)}</p>
            </Link>
          ))}
        </div>
      </section>

      <section className="container-page mt-24" aria-labelledby="how">
        <div className="grid gap-10 md:grid-cols-[1fr_2fr]">
          <div>
            <p className="eyebrow">{t("How it works")}</p>
            <h2 id="how" className="mt-3 text-3xl font-semibold tracking-tight">{t("Three steps, no account.")}</h2>
          </div>
          <ol className="grid gap-px overflow-hidden rounded-xl border border-border bg-border md:grid-cols-3">
            {steps.map((s) => (
              <li key={s.n} className="bg-card p-6">
                <span className="font-mono text-sm text-primary">{s.n}</span>
                <h3 className="mt-4 font-semibold">{t(s.t)}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{t(s.d)}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>
    </>
  );
}
