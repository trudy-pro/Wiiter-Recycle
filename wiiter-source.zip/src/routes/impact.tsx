import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, HeartHandshake, Info, Leaf, Recycle, RefreshCw, Tag, Trash2, Wallet, Wrench } from "lucide-react";
import type { ComponentType } from "react";
import { useAppState, actions } from "@/lib/store";
import { useT } from "@/lib/i18n";
import { estimateKg, estimateCo2, estimateValueChf, secondLifeCount, KG_PER_ITEM, VALUE_CHF_PER_SOLD } from "@/lib/impact";
import { itemLabels } from "@/data/labels";
import { exampleOutcomes } from "@/data/impact-examples";
import type { OutcomeType } from "@/data/types";
import type { OutcomeRecord } from "@/lib/store";

export const Route = createFileRoute("/impact")({
  head: () => ({
    meta: [
      { title: "Your impact — Wiiter" },
      { name: "description", content: "See how many items you kept in use and the waste, CO₂e and value saved." },
      { property: "og:title", content: "Your impact — Wiiter" },
      { property: "og:description", content: "A simple personal dashboard of items given a second life." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Impact,
});

type Kind = "sold" | "donated" | "reused" | "repaired" | "recycled";
const kinds: { id: Kind; label: string; icon: ComponentType<{ className?: string }>; color: string }[] = [
  { id: "sold", label: "Resold", icon: Tag, color: "bg-lime" },
  { id: "donated", label: "Donated", icon: HeartHandshake, color: "bg-directory-icon" },
  { id: "reused", label: "Reused", icon: RefreshCw, color: "bg-accent" },
  { id: "repaired", label: "Repaired", icon: Wrench, color: "bg-foreground" },
  { id: "recycled", label: "Recycled", icon: Recycle, color: "bg-muted-foreground" },
];
const kindOf = (o: OutcomeType) => kinds.find((k) => k.id === o);

function arcPath(start: number, end: number) {
  const point = (angle: number) => {
    const radians = (angle * Math.PI) / 180;
    return [180 + 150 * Math.cos(radians), 178 + 150 * Math.sin(radians)];
  };
  const [sx, sy] = point(start);
  const [ex, ey] = point(end);
  return `M ${sx} ${sy} A 150 150 0 ${end - start > 180 ? 1 : 0} 1 ${ex} ${ey}`;
}

const gaugeColors: Record<Kind, string> = {
  sold: "text-lime",
  donated: "text-directory-icon",
  reused: "text-accent-foreground",
  repaired: "text-foreground",
  recycled: "text-muted-foreground",
};
const badgeColors: Record<Kind, string> = {
  sold: "bg-lime text-lime-foreground",
  donated: "bg-warning text-warning-foreground",
  reused: "bg-accent text-accent-foreground",
  repaired: "bg-primary text-primary-foreground",
  recycled: "bg-muted text-muted-foreground",
};

function Tip({ text }: { text: string }) {
  return <span className="group relative inline-flex align-middle">
    <button type="button" aria-label={text} className="rounded-full text-muted-foreground hover:text-foreground focus-visible:text-foreground"><Info className="h-3.5 w-3.5" aria-hidden /></button>
    <span role="tooltip" className="pointer-events-none absolute bottom-full left-1/2 z-10 mb-2 w-56 -translate-x-1/2 rounded-lg bg-foreground px-3 py-2 text-xs font-normal text-background opacity-0 transition-opacity group-hover:opacity-100 group-focus-within:opacity-100">{text}</span>
  </span>;
}

function Impact() {
  const t = useT();
  const { outcomes: real } = useAppState();
  const isExample = !real.some((o) => o.outcome !== "unresolved");
  const outcomes: (OutcomeRecord & { name?: string })[] = isExample ? exampleOutcomes : real.filter((o) => o.outcome !== "unresolved");
  const kept = secondLifeCount(outcomes);
  const counts = kinds.map((k) => ({ ...k, n: outcomes.filter((o) => o.outcome === k.id).length }));
  const total = Math.max(outcomes.length, 1);
  const dots = Math.max(5, Math.ceil((kept + 1) / 5) * 5);
  const keptCounts = counts.filter((c) => c.n > 0 && ["sold", "donated", "reused"].includes(c.id));
  let angle = 150;
  const segments = keptCounts.map((c) => {
    const sweep = (c.n / Math.max(kept, 1)) * 240;
    const start = angle;
    angle += sweep;
    return { ...c, path: arcPath(start + (start > 150 ? 3 : 0), angle - (angle < 390 ? 3 : 0)) };
  });

  const metrics = [
    { icon: Trash2, value: `≈ ${estimateKg(outcomes).toFixed(0)} kg`, label: "Waste avoided", tip: "Approximate weight of items kept out of the bin." },
    { icon: Leaf, value: `≈ ${estimateCo2(outcomes).toFixed(0)} kg`, label: "CO₂e avoided", tip: "CO₂e and waste figures are approximate estimates based on recorded outcomes." },
    { icon: Wallet, value: `CHF ${estimateValueChf(outcomes)}`, label: "Value recovered", tip: "Estimated resale value of items you sold." },
  ];

  return (
    <div className="container-page max-w-4xl pt-12 md:pt-16">
      <div className="flex flex-wrap items-center gap-2">
        <p className="eyebrow">{t("Your impact")}</p>
        {isExample && <span className="rounded-full bg-secondary px-2.5 py-0.5 text-xs font-medium">{t("Example")}</span>}
      </div>

      <section className="relative mt-6 flex min-h-80 flex-col justify-between gap-8 sm:flex-row sm:items-end" aria-label={t("items kept in use")}>
        <div className="w-full max-w-96 self-center sm:self-start">
          <div className="relative aspect-[360/280]">
            <svg viewBox="0 0 360 280" className="h-full w-full overflow-visible" aria-hidden="true">
              <path d={arcPath(150, 390)} fill="none" stroke="currentColor" strokeWidth="20" strokeLinecap="round" className="text-muted" />
              {segments.map((segment) => <path key={segment.id} d={segment.path} fill="none" stroke="currentColor" strokeWidth="20" strokeLinecap="round" className={gaugeColors[segment.id]} />)}
            </svg>
            <div className="absolute inset-x-10 top-[30%] flex flex-col items-center text-center">
              <p className="text-7xl font-semibold leading-none tabular-nums sm:text-8xl">{kept}</p>
              <p className="mt-3 max-w-60 text-lg leading-snug">{t("items kept in use")}</p>
              <div className="mt-5 flex max-w-52 flex-wrap justify-center gap-1.5" aria-label={`${kept} / ${dots}`}>
                {Array.from({ length: dots }, (_, i) => <span key={i} className={`h-3 w-3 rounded-full ${i < kept ? "bg-lime" : "border border-input"}`} />)}
              </div>
            </div>
          </div>
          <ul className="flex flex-wrap justify-center gap-2">
            {counts.filter((c) => c.n > 0 && c.id !== "recycled").map((c) => <li key={c.id} className={`inline-flex items-center gap-1.5 rounded-full px-3 py-2 text-xs ${badgeColors[c.id]}`}><c.icon className="h-3.5 w-3.5 shrink-0" aria-hidden /><span className="font-semibold">{c.n}</span>{t(c.label)}</li>)}
          </ul>
        </div>
        <svg viewBox="0 0 120 120" className="absolute right-0 top-0 hidden h-28 w-28 sm:block" aria-hidden="true">
          {Array.from({ length: 24 }, (_, i) => <rect key={i} x={8 + ((i * 37) % 104)} y={8 + ((i * 23) % 96)} width={i % 3 === 0 ? 3 : 5} height={i % 3 === 0 ? 3 : 8} rx="1" transform={`rotate(${i * 29}, ${10 + ((i * 37) % 104)}, ${12 + ((i * 23) % 96)})`} fill="currentColor" className={["text-lime", "text-directory-icon", "text-accent-foreground", "text-secondary-foreground"][i % 4]} />)}
        </svg>
        <p className="pb-2 text-center text-base font-medium sm:text-right">{t("Keep going!")}</p>
      </section>
      {isExample && <p className="mt-5 text-sm text-muted-foreground">{t("Your impact starts with your first item.")}</p>}

      <section className="mt-12 grid grid-cols-1 gap-3 border-t border-border pt-10 sm:grid-cols-3">
        {metrics.map((m) => <div key={m.label} className="rounded-2xl bg-card p-5">
          <m.icon className="h-5 w-5 text-muted-foreground" aria-hidden />
          <p className="mt-3 text-3xl font-semibold tracking-tight">{m.value}</p>
          <p className="mt-1 flex items-center gap-1.5 text-xs text-muted-foreground">{t(m.label)} <Tip text={t(m.tip)} /></p>
        </div>)}
      </section>

      <section className="mt-12 border-t border-border pt-10" aria-labelledby="outcomes">
        <h2 id="outcomes" className="eyebrow">{t("Outcomes")}</h2>
        <div className="mt-5 flex h-4 w-full overflow-hidden rounded-full bg-muted" aria-hidden>
          {counts.filter((c) => c.n > 0).map((c) => <span key={c.id} className={c.color} style={{ width: `${(c.n / total) * 100}%` }} />)}
        </div>
        <ul className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
          {counts.filter((c) => c.id !== "repaired" || c.n > 0).map((c) => <li key={c.id} className="flex items-center gap-2 text-sm">
            <span className={`h-2.5 w-2.5 rounded-full ${c.color}`} aria-hidden />{t(c.label)}<span className="ml-auto font-semibold sm:ml-0">{c.n}</span>
          </li>)}
        </ul>
      </section>

      <section className="mt-12 border-t border-border pt-10" aria-labelledby="activity">
        <h2 id="activity" className="eyebrow">{t("Recent activity")}</h2>
        <ul className="mt-4 divide-y divide-border">
          {outcomes.slice().reverse().map((o) => {
            const k = kindOf(o.outcome);
            const Icon = k?.icon ?? Recycle;
            const impact = o.outcome === "sold" ? `CHF ${VALUE_CHF_PER_SOLD}` : `≈ ${KG_PER_ITEM[o.item]} kg`;
            return <li key={o.id} className="grid grid-cols-[auto_minmax(0,1fr)_auto_auto] items-center gap-3 py-3.5">
              <span className="grid h-9 w-9 place-items-center rounded-full bg-muted"><Icon className="h-4 w-4" aria-hidden /></span>
              <span className="truncate font-medium">{t(o.name ?? itemLabels[o.item])}</span>
              <span className="rounded-full bg-secondary px-2.5 py-0.5 text-xs font-semibold uppercase tracking-wide">{t(k?.label ?? "")}</span>
              <span className="w-16 text-right text-sm tabular-nums text-muted-foreground">{impact}</span>
            </li>;
          })}
        </ul>
        <p className="mt-4 flex items-center gap-1.5 text-xs text-muted-foreground">{t("Impact estimates")} <Tip text={t("CO₂e and waste figures are approximate estimates based on recorded outcomes.")} /></p>
        {!isExample && <button className="mt-4 text-xs text-muted-foreground underline-offset-4 hover:underline" onClick={() => { if (window.confirm(t("Clear all recorded outcomes on this device?"))) actions.clearOutcomes(); }}>{t("Clear recorded outcomes")}</button>}
      </section>

      <section className="mt-12 border-t border-border pt-10 text-center">
        <p className="text-xl font-semibold">{t("Give another item a second chance")}</p>
        <div className="mt-5 flex flex-col items-center gap-4">
          <Link to="/assess" className="btn btn-primary w-full sm:w-auto">{t("Find my next step")}</Link>
          <Link to="/explore" className="inline-flex items-center gap-1.5 text-sm font-medium underline-offset-4 hover:underline">{t("Explore directory")}<ArrowRight className="h-4 w-4" aria-hidden /></Link>
        </div>
      </section>
    </div>
  );
}
