import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { PrettyGoodResult } from "@/components/PrettyGoodResult";
import { RepairRecommendation } from "@/components/RepairRecommendation";
import { ItemPhoto } from "@/components/ItemPhoto";
import { Button } from "@/components/ui/button";
import { itemLabels, conditionLabels, priorityLabels, transportLabels } from "@/data/labels";
import { isComplete, recommend } from "@/lib/engine";
import type { Recommendation } from "@/lib/engine";
import { assessPrettyGood } from "@/lib/prettygood";
import { trackPilotEvent } from "@/lib/pilot";
import { actions, useAppState } from "@/lib/store";
import { useT } from "@/lib/i18n";
import type { CompleteAnswers } from "@/data/types";

/** Records pilot analytics once per completed assessment. Events stay on this device. */
function PilotTracking({ result, answers }: { result: Recommendation; answers: CompleteAnswers }) {
  const key = JSON.stringify(answers);
  const last = useRef<string | null>(null);
  useEffect(() => {
    if (last.current === key) return;
    last.current = key;
    trackPilotEvent("item_analyzed", answers.item);
    trackPilotEvent("recommendation_viewed", result.primary.action);
    const action = result.primary.action;
    if (assessPrettyGood(answers).fit === "likely") trackPilotEvent("pretty_good_recommended");
    if (action === "repair") trackPilotEvent("repair_recommended");
    if (action === "donate") trackPilotEvent("donate_recommended");
    if (action === "recycle") trackPilotEvent("recycle_recommended");
    let prev: string | null = null;
    try { prev = window.localStorage.getItem("scb-pilot-route"); } catch { /* memory only */ }
    if (prev && prev !== action) trackPilotEvent("recommendation_changed");
    try { window.localStorage.setItem("scb-pilot-route", action); } catch { /* memory only */ }
  }, [key, result, answers]);
  return null;
}

export const Route = createFileRoute("/assess")({
  head: () => ({
    meta: [
      { title: "Your repair recommendation — Wiiter" },
      { name: "description", content: "Find local places and useful resources to repair, donate, sell or recycle your item in Basel." },
      { property: "og:title", content: "Your repair recommendation — Wiiter" },
      { property: "og:description", content: "From repair to disposal: practical places to give your item a second chance." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Assessment,
});

const questions = [
  { key: "item", title: "What item do you have?", labels: itemLabels },
  { key: "condition", title: "What is its condition?", labels: conditionLabels },
  { key: "priority", title: "What matters most?", labels: priorityLabels },
  { key: "transport", title: "Can you transport the item?", labels: transportLabels },
] as const;

function Assessment() {
  const t = useT();
  const { answers } = useAppState();
  const [step, setStep] = useState(0);
  const [finished, setFinished] = useState(false);
  const [photo, setPhoto] = useState<File | null>(null);
  const question = questions[step];
  const result = finished && isComplete(answers) ? recommend(answers) : null;

  if (result && isComplete(answers)) {
    return <>
      <PilotTracking result={result} answers={answers} />
      <PrettyGoodResult answers={answers} />
      <RepairRecommendation recommendation={result} answers={answers} />
      <div className="container-page max-w-4xl pb-8">
        <Button variant="outline" onClick={() => { setFinished(false); setStep(0); }}><ArrowLeft aria-hidden />{t("Edit")}</Button>
      </div>
    </>;
  }
  if (!question) return null;

  return <div className="container-page max-w-4xl pt-10 md:pt-14">
    <p className="text-sm font-semibold uppercase text-muted-foreground">{t("Step X of 4").replace("X", String(step + 1))}</p>
    <div role="progressbar" aria-label={t("Find my next step")} aria-valuemin={0} aria-valuemax={4} aria-valuenow={step + 1} className="mt-3 grid h-1.5 grid-cols-4 gap-1 overflow-hidden rounded-full bg-muted">
      {questions.map((q, i) => <span key={q.key} className={i <= step ? "bg-lime" : "bg-muted"} />)}
    </div>
    <h1 className="mt-8 text-2xl font-semibold md:text-3xl">{t(question.title)}</h1>
    <div role="group" aria-label={t(question.title)} className="mt-6 flex flex-wrap gap-3">
      {Object.entries(question.labels).map(([value, label]) => <Button key={value} variant="outline" aria-pressed={answers[question.key] === value} className={`h-auto min-h-11 whitespace-normal rounded-full px-5 py-3 text-left ${answers[question.key] === value ? "border-lime bg-lime text-lime-foreground hover:bg-lime/90 hover:text-lime-foreground" : ""}`} onClick={() => {
        switch (question.key) {
          case "item": if (value in itemLabels) actions.setAnswer("item", value as keyof typeof itemLabels); break;
          case "condition": if (value in conditionLabels) actions.setAnswer("condition", value as keyof typeof conditionLabels); break;
          case "priority": if (value in priorityLabels) actions.setAnswer("priority", value as keyof typeof priorityLabels); break;
          case "transport": if (value in transportLabels) actions.setAnswer("transport", value as keyof typeof transportLabels); break;
        }
      }}>{t(label)}</Button>)}
    </div>
    {step === 0 && <ItemPhoto file={photo} onChange={setPhoto} />}
    <div className="mt-8 flex justify-between gap-3 border-t border-border pt-6">
      <Button variant="outline" disabled={step === 0} onClick={() => setStep(step - 1)}><ArrowLeft aria-hidden />{t("Back")}</Button>
      <Button disabled={!answers[question.key]} onClick={() => { if (step === 3) setFinished(true); else setStep(step + 1); }}>{t(step === 3 ? "See my next step" : "Continue")}<ArrowRight aria-hidden /></Button>
    </div>
  </div>;
}
