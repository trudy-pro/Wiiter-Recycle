import { createFileRoute, Link } from "@tanstack/react-router";
import { useLanguage, useT } from "@/lib/i18n";
import { canEdit, partnerActions, usePartnerState } from "@/lib/partner-store";
import { formatVerifiedDate } from "@/lib/sources";
import type { ReportStatus } from "@/data/partner";

export const Route = createFileRoute("/partner/reports")({ component: PartnerReports });

const reportStatusStyles: Record<ReportStatus, string> = {
  Open: "bg-warning text-warning-foreground",
  Confirmed: "bg-secondary text-secondary-foreground",
  Resolved: "bg-accent text-accent-foreground",
  Rejected: "bg-muted text-muted-foreground",
};

function PartnerReports() {
  const t = useT();
  const { lang } = useLanguage();
  const { orgId, role, reports } = usePartnerState();
  const mine = reports.filter((r) => r.orgId === orgId);

  return <div>
    <h2 className="text-2xl font-semibold">{t("User reports")}</h2>
    <p className="mt-2 text-sm text-muted-foreground">{t("Reports submitted from the Wiiter consumer interface.")}</p>
    <ul className="mt-6 grid gap-3">
      {mine.map((report) => <li key={report.id} className="rounded-xl border border-border p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="font-semibold">{t(report.type)}</h3>
            <p className="text-sm text-muted-foreground">{report.target} · {formatVerifiedDate(report.date, lang)}</p>
          </div>
          <span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${reportStatusStyles[report.status]}`}>{t(report.status)}</span>
        </div>
        <p className="mt-3 text-sm">“{t(report.comment)}”</p>
        <p className="mt-1 text-sm text-muted-foreground">{t("Current data")}: {report.currentData}</p>
        {canEdit(role) && report.status !== "Resolved" && <div className="mt-4 flex flex-wrap gap-2">
          {report.status === "Open" && <>
            <button type="button" onClick={() => partnerActions.setReportStatus(report.id, "Confirmed")} className="btn btn-outline !px-4 !py-2 text-sm">{t("Confirm issue")}</button>
            <button type="button" onClick={() => partnerActions.setReportStatus(report.id, "Rejected")} className="btn btn-outline !px-4 !py-2 text-sm">{t("Reject report")}</button>
          </>}
          <Link to="/partner/locations" className="btn btn-outline !px-4 !py-2 text-sm">{t("Update information")}</Link>
          <button type="button" onClick={() => partnerActions.setReportStatus(report.id, "Resolved")} className="btn btn-primary !px-4 !py-2 text-sm">{t("Mark resolved")}</button>
        </div>}
      </li>)}
      {mine.length === 0 && <li className="rounded-xl border border-border p-5 text-sm text-muted-foreground">{t("No reports for this organization yet.")}</li>}
    </ul>
  </div>;
}
