import { createFileRoute, Link, Outlet } from "@tanstack/react-router";
import { useT } from "@/lib/i18n";
import { partnerOrgs, partnerRoleDescriptions, type PartnerRole } from "@/data/partner";
import { partnerActions, usePartnerState } from "@/lib/partner-store";

export const Route = createFileRoute("/partner")({
  head: () => ({
    meta: [
      { title: "Partner portal — Wiiter" },
      { name: "description", content: "Partner organizations maintain and verify the data behind Wiiter recommendations." },
      { property: "og:title", content: "Partner portal — Wiiter" },
      { property: "og:description", content: "Keep locations, rules and opening hours verified." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PartnerLayout,
});

const partnerNav = [
  { to: "/partner", label: "Dashboard", exact: true },
  { to: "/partner/locations", label: "Locations" },
  { to: "/partner/items", label: "Accepted items" },
  { to: "/partner/rules", label: "Rules" },
  { to: "/partner/reports", label: "Reports" },
  { to: "/partner/history", label: "Verification history" },
  { to: "/partner/settings", label: "Organization settings" },
] as const;

function PartnerLayout() {
  const t = useT();
  const { orgId, role } = usePartnerState();
  return <div className="container-page pt-10 md:pt-14">
    <div className="flex flex-wrap items-end justify-between gap-4">
      <div>
        <p className="eyebrow">{t("Partner portal")}</p>
        <h1 className="mt-2 text-3xl font-semibold leading-tight">{t(partnerOrgs.find((o) => o.id === orgId)?.name ?? "Partner")}</h1>
        <p className="mt-1 text-sm text-muted-foreground">{t("Demo access, no sign in required.")}</p>
      </div>
      <div className="flex flex-wrap gap-2">
        <label className="flex items-center gap-2 text-sm">
          <span className="text-muted-foreground">{t("Organization")}</span>
          <select value={orgId} onChange={(e) => partnerActions.setOrg(e.target.value)} className="rounded-full border border-input bg-background px-3 py-1.5 text-sm">
            {partnerOrgs.map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}
          </select>
        </label>
        <label className="flex items-center gap-2 text-sm" title={t(partnerRoleDescriptions[role])}>
          <span className="text-muted-foreground">{t("Role")}</span>
          <select value={role} onChange={(e) => partnerActions.setRole(e.target.value as PartnerRole)} className="rounded-full border border-input bg-background px-3 py-1.5 text-sm">
            {(["Admin", "Editor", "Verifier", "Viewer"] as const).map((r) => <option key={r} value={r}>{t(r)}</option>)}
          </select>
        </label>
      </div>
    </div>
    <p className="mt-2 text-xs text-muted-foreground">{t(role)}: {t(partnerRoleDescriptions[role])}</p>
    <nav className="mt-6 flex flex-wrap gap-1 border-b border-border pb-3 text-sm" aria-label={t("Partner portal")}>
      {partnerNav.map((n) => <Link key={n.to} to={n.to} activeOptions={{ exact: "exact" in n }} className="rounded-full px-3 py-1.5 text-muted-foreground hover:text-foreground" activeProps={{ className: "bg-accent text-accent-foreground" }}>
        {t(n.label)}
      </Link>)}
    </nav>
    <div className="pt-8"><Outlet /></div>
  </div>;
}
