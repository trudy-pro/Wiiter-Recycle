import { createFileRoute } from "@tanstack/react-router";
import { BadgeCheck } from "lucide-react";
import { useT } from "@/lib/i18n";
import { dataFreshness, usePartnerState } from "@/lib/partner-store";
import { freshness } from "@/lib/sources";
import { formatVerifiedDate } from "@/lib/sources";
import { useLanguage } from "@/lib/i18n";

export const Route = createFileRoute("/partner/")({ component: PartnerDashboard });

function PartnerDashboard() {
  const t = useT();
  const { lang } = useLanguage();
  const state = usePartnerState();
  const score = dataFreshness(state);
  const locations = state.locations.filter((l) => l.orgId === state.orgId);
  const rules = state.rules.filter((r) => r.orgId === state.orgId);
  const dates = [...locations, ...rules].map((x) => x.lastVerified).sort();
  const lastVerification = dates.at(-1);
  const allVerified = [...locations, ...rules].every((x) => x.status === "Verified");

  const stats = [
    { label: "Verification status", value: allVerified ? t("Verified") : t("Needs review") },
    { label: "Active locations", value: String(locations.filter((l) => l.active).length) },
    { label: "Active routing rules", value: String(rules.length) },
    { label: "Pending user reports", value: String(score.openReports) },
    { label: "Last verification", value: lastVerification ? formatVerifiedDate(lastVerification, lang) : "—" },
  ];

  return <div>
    <dl className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
      {stats.map((s) => <div key={s.label} className="rounded-xl border border-border p-5">
        <dt className="text-sm text-muted-foreground">{t(s.label)}</dt>
        <dd className="mt-2 flex items-center gap-2 text-2xl font-semibold">
          {s.label === "Verification status" && allVerified && <BadgeCheck className="h-5 w-5 text-directory-heading" aria-hidden />}
          {s.value}
        </dd>
      </div>)}
      <div className="rounded-xl border border-border p-5">
        <dt className="text-sm text-muted-foreground">{t("Data freshness")}</dt>
        <dd className="mt-2 text-2xl font-semibold">{score.score}%</dd>
        <div className="mt-2 h-2 overflow-hidden rounded-full bg-muted">
          <div className="h-full rounded-full bg-lime" style={{ width: `${score.score}%` }} />
        </div>
      </div>
    </dl>

    <section className="mt-8 rounded-xl border border-border p-5" aria-labelledby="freshness-breakdown">
      <h2 id="freshness-breakdown" className="font-semibold">{t("Freshness breakdown")}</h2>
      <ul className="mt-3 space-y-2 text-sm">
        <li className="flex justify-between gap-3"><span>{t("Locations verified recently")}</span><span className="font-medium">{score.locationsRecent}/{score.locationsTotal}</span></li>
        <li className="flex justify-between gap-3"><span>{t("Acceptance rules verified recently")}</span><span className="font-medium">{score.rulesRecent}/{score.rulesTotal}</span></li>
        <li className="flex justify-between gap-3"><span>{t("Opening hours verified recently")}</span><span className="font-medium">{score.hoursRecent}/{score.hoursTotal}</span></li>
        <li className="flex justify-between gap-3"><span>{t("User reports awaiting review")}</span><span className="font-medium">{score.openReports}</span></li>
      </ul>
    </section>

    {[...locations.map((l) => ({ name: l.name, date: l.lastVerified })), ...rules.map((r) => ({ name: `Rule ${r.code}`, date: r.lastVerified }))]
      .filter((x) => freshness(x.date).level !== "recent")
      .map((x) => <p key={x.name} className="mt-3 flex items-start gap-2 rounded-xl bg-warning px-4 py-3 text-sm text-warning-foreground">
        {freshness(x.date).level === "outdated"
          ? t("Needs review:") + ` ${x.name} — ${t("Last verified")} ${formatVerifiedDate(x.date, lang)}`
          : t("Verification recommended:") + ` ${x.name} — ${t("Last verified")} ${formatVerifiedDate(x.date, lang)}`}
      </p>)}
  </div>;
}
