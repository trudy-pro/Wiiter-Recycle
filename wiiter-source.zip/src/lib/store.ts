import { useSyncExternalStore } from "react";
import type { ActionType, Answers, ItemCategory, OutcomeType } from "@/data/types";

export interface OutcomeRecord {
  id: string;
  item: ItemCategory;
  action: ActionType;
  outcome: OutcomeType;
  date: string;
}

interface State {
  answers: Answers;
  outcomes: OutcomeRecord[];
}

const KEY = "scb-state-v1";
const EMPTY: State = { answers: {}, outcomes: [] };
let state: State = EMPTY;
let loaded = false;
export let persistent = false;
const listeners = new Set<() => void>();

function load() {
  if (loaded || typeof window === "undefined") return;
  loaded = true;
  try {
    const raw = window.localStorage.getItem(KEY);
    if (raw) state = { ...EMPTY, ...JSON.parse(raw) };
    persistent = true;
  } catch {
    persistent = false;
  }
}

function set(next: State) {
  state = next;
  try {
    window.localStorage.setItem(KEY, JSON.stringify(state));
  } catch {
    /* memory only */
  }
  listeners.forEach((l) => l());
}

function subscribe(l: () => void) {
  load();
  listeners.add(l);
  l();
  return () => listeners.delete(l);
}

export function useAppState(): State {
  return useSyncExternalStore(subscribe, () => state, () => EMPTY);
}

export const actions = {
  setAnswer<K extends keyof Answers>(k: K, v: Answers[K]) {
    set({ ...state, answers: { ...state.answers, [k]: v } });
  },
  resetAnswers() {
    set({ ...state, answers: {} });
  },
  addOutcome(r: Omit<OutcomeRecord, "id" | "date">) {
    const rec = { ...r, id: crypto.randomUUID(), date: new Date().toISOString() };
    set({ ...state, outcomes: [...state.outcomes, rec] });
    return rec;
  },
  clearOutcomes() {
    set({ ...state, outcomes: [] });
  },
};
