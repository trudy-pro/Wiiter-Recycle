import { describe, expect, it } from "vitest";
import { assessPrettyGood, mapsUrl, prettyGoodLocations } from "./prettygood";

describe("Pretty Good eligibility", () => {
  it("routes the demo lamp scenario to Pretty Good as likely suitable", () => {
    // "Small table lamp. Works, but the shade is scratched." = electrical + damaged
    const r = assessPrettyGood({ item: "electrical", condition: "damaged", priority: "second-life", transport: "walk" });
    expect(r.fit).toBe("likely");
    expect(r.reasons).toContain("Category accepted by Pretty Good");
    expect(r.reasons).toContain("Damage looks cosmetic");
    expect(r.reusePotential).toBe("High");
  });

  it("never guarantees acceptance for broken items", () => {
    const r = assessPrettyGood({ item: "electrical", condition: "broken", priority: "convenient", transport: "car" });
    expect(r.fit).toBe("unlikely");
    expect(r.alternative).toBe("recycle");
  });

  it("does not route textiles to Pretty Good", () => {
    const r = assessPrettyGood({ item: "textiles", condition: "works", priority: "second-life", transport: "walk" });
    expect(r.fit).toBe("unlikely");
    expect(r.alternative).toBe("donate");
  });

  it("stays cautious when the condition is unsure", () => {
    const r = assessPrettyGood({ item: "tool", condition: "unsure", priority: "cheap", transport: "transit" });
    expect(r.fit).toBe("possible");
    expect(r.alternative).toBe("unsure");
  });

  it("offers two demo collection points with map links", () => {
    expect(prettyGoodLocations.map((l) => l.name)).toEqual(["Lottner AG", "Werkhof / Recyclingpark Riehen"]);
    for (const loc of prettyGoodLocations) expect(mapsUrl(loc)).toMatch(/^https:\/\/www\.google\.com\/maps\/search\//);
  });
});
