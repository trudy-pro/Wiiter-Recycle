/** Lightweight pilot analytics. Events stay on this device until a real backend exists. */

export type PilotEventName =
  | "item_analyzed"
  | "pretty_good_recommended"
  | "pretty_good_location_selected"
  | "repair_recommended"
  | "donate_recommended"
  | "recycle_recommended"
  | "recommendation_changed"
  | "user_feedback_positive"
  | "user_feedback_negative"
  | "source_opened"
  | "source_clicked"
  | "recommendation_viewed"
  | "recommendation_accepted"
  | "recommendation_rejected"
  | "destination_selected"
  | "outcome_reported"
  | "outcome_accepted"
  | "outcome_rejected"
  | "information_reported_outdated"
  | "recommendation_accuracy_yes"
  | "recommendation_accuracy_partial"
  | "recommendation_accuracy_no";

export interface PilotEvent {
  name: PilotEventName;
  date: string;
  detail?: string;
}

const KEY = "scb-pilot-v1";

export function getPilotEvents(): PilotEvent[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as PilotEvent[]) : [];
  } catch {
    return [];
  }
}

export function trackPilotEvent(name: PilotEventName, detail?: string) {
  if (typeof window === "undefined") return;
  try {
    const events = getPilotEvents();
    events.push({ name, date: new Date().toISOString(), ...(detail ? { detail } : {}) });
    window.localStorage.setItem(KEY, JSON.stringify(events.slice(-500)));
  } catch {
    /* memory only */
  }
}

export function countPilotEvents(name: PilotEventName): number {
  return getPilotEvents().filter((e) => e.name === name).length;
}
