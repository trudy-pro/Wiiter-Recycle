import { describe, expect, it } from "vitest";
import { de } from "./translations";
import { scoreRoutes, recommend } from "./engine";
import {
  actionLabels,
  conditionLabels,
  itemLabels,
  outcomeLabels,
  priorityLabels,
  transportLabels,
} from "../data/labels";
import { options } from "../data/options";
import { impactExamples } from "../data/impact-examples";


/** Collects every German translation used for an answer grid, so no dynamic engine string is missed. */
function collectEngineStrings(): string[] {
  const strings: string[] = [];
  const items = Object.keys(itemLabels) as (keyof typeof itemLabels)[];
  const conditions = Object.keys(conditionLabels) as (keyof typeof conditionLabels)[];
  const priorities = Object.keys(priorityLabels) as (keyof typeof priorityLabels)[];
  const transports = Object.keys(transportLabels) as (keyof typeof transportLabels)[];
  for (const item of items)
    for (const condition of conditions)
      for (const priority of priorities)
        for (const transport of transports) {
          const answers = { item, condition, priority, transport } as const;
          for (const route of scoreRoutes(answers)) strings.push(...route.reasons);
          const rec = recommend(answers);
          if (!rec) continue;
          strings.push(...rec.notes, ...rec.checklist, ...rec.verifyQuestions);
          for (const alt of rec.alternatives) strings.push(alt.reasons[0] ?? "Another possible route for your item.");
        }
  return strings;
}

describe("german translations", () => {
  it("translates every question and outcome label", () => {
    const labels = [
      ...Object.values(itemLabels),
      ...Object.values(conditionLabels),
      ...Object.values(priorityLabels),
      ...Object.values(transportLabels),
      ...Object.values(actionLabels),
      ...Object.values(outcomeLabels),
    ];
    for (const label of labels) expect(de[label], label).toBeTruthy();
  });

  it("translates every explore option's texts", () => {
    for (const o of options) {
      expect(de[o.title], o.title).toBeTruthy();
      expect(de[o.description], o.description).toBeTruthy();
      expect(de[o.eligibilityNotes], o.eligibilityNotes).toBeTruthy();
      for (const step of o.nextSteps) expect(de[step], step).toBeTruthy();
    }
  });




  it("translates every recommendation reason, note, checklist and verify question", () => {
    for (const s of collectEngineStrings()) expect(de[s], s).toBeTruthy();
  });

  it("translates every impact example row's texts", () => {
    for (const e of impactExamples) {
      expect(de[e.item], e.item).toBeTruthy();
      expect(de[e.action], e.action).toBeTruthy();
      expect(de[e.detail], e.detail).toBeTruthy();
      expect(de[e.tag], e.tag).toBeTruthy();
    }
  });
});
