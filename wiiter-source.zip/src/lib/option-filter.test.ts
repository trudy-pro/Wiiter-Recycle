import { describe, expect, it } from "vitest";
import { options } from "@/data/options";
import { filterOptions } from "./option-filter";

describe("shared Explore matching", () => {
  it("matches electrical repair to the repair café and electronics workshop", () => {
    expect(filterOptions(options, { action: "repair", item: "electrical" }).map((o) => o.id)).toEqual(["basel-reparierbar", "repair-directory", "ex-repair-cafe", "ex-electronics-repair"]);
  });
  it("switches to recycling without losing the selected electrical category", () => {
    expect(filterOptions(options, { action: "recycle", item: "electrical" }).map((o) => o.id)).toEqual(["sens-recycling", "ex-electrical-takeback", "ex-recycling-point"]);
  });
  it("full browsing includes every existing option", () => {
    expect(filterOptions(options, {})).toHaveLength(24);
  });
  it("combines search, action and item filters", () => {
    expect(filterOptions(options, { q: "seams", action: "repair", item: "textiles" }).map((o) => o.id)).toEqual(["ex-tailor"]);
    expect(filterOptions(options, { q: "seams", action: "repair", item: "electrical" })).toEqual([]);
  });
  it("only matches confirmed free services, never unknown prices", () => {
    const base = options[0];
    if (!base) throw new Error("Missing fixture");
    expect(filterOptions([{ ...base, id: "free", free: true }, { ...base, id: "unknown" }], { free: true }).map((o) => o.id)).toEqual(["free"]);
  });
  it("only matches confirmed damaged-item acceptance", () => {
    const base = options[0];
    if (!base) throw new Error("Missing fixture");
    expect(filterOptions([{ ...base, id: "yes", acceptsDamaged: true }, { ...base, id: "no", acceptsDamaged: false }], { acceptsDamaged: true }).map((o) => o.id)).toEqual(["yes"]);
  });
  it("only matches confirmed pickup availability", () => {
    const base = options[0];
    if (!base) throw new Error("Missing fixture");
    expect(filterOptions([{ ...base, id: "pickup", pickupAvailable: true }, base], { pickupAvailable: true }).map((o) => o.id)).toEqual(["pickup"]);
  });
  it("only matches services requiring appointments", () => {
    const base = options[0];
    if (!base) throw new Error("Missing fixture");
    expect(filterOptions([{ ...base, id: "appointment", appointmentRequired: true }, base], { appointmentRequired: true }).map((o) => o.id)).toEqual(["appointment"]);
  });
  it("matches collection points separately from recommendation scoring", () => {
    const base = options[0];
    if (!base) throw new Error("Missing fixture");
    expect(filterOptions([{ ...base, directoryCategories: ["collection"], directoryItems: ["electronics"] }], { category: "collection", directoryItem: "electronics" })).toHaveLength(1);
  });
});