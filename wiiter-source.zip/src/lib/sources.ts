/** Structured source data for recommendations. Dates live here, never hardcoded in the UI. */

export type SourceType = "official" | "partner" | "repair-network" | "recycling" | "reuse" | "community";

export interface SourceInfo {
  id: string;
  sourceName: string;
  organization: string;
  description: string;
  sourceUrl: string;
  sourceType: SourceType;
  lastVerified: string; // ISO date, e.g. "2026-10-18"
}

export const sourceTypeLabels: Record<SourceType, string> = {
  official: "Official municipal source",
  partner: "Partner source",
  "repair-network": "Repair network",
  recycling: "Recycling provider",
  reuse: "Reuse organization",
  community: "Community resource",
};

export const prettyGoodSources: SourceInfo[] = [
  {
    id: "pg-basel",
    sourceName: "Pretty Good Basel",
    organization: "Basel-Stadt",
    description: "Official information about accepted reusable household goods.",
    sourceUrl: "https://www.bs.ch",
    sourceType: "official",
    lastVerified: "2026-10-18",
  },
  {
    id: "pg-collection",
    sourceName: "Collection point information",
    organization: "Pretty Good Basel",
    description: "Locations and acceptance rules for reusable items.",
    sourceUrl: "https://www.bs.ch",
    sourceType: "partner",
    lastVerified: "2026-10-18",
  },
];

export type Freshness = "recent" | "verified" | "outdated";

export const freshnessLabels: Record<Freshness, string> = {
  recent: "Verified recently",
  verified: "Verified",
  outdated: "May be outdated",
};

const DAY = 24 * 60 * 60 * 1000;

/** 0 to 30 days: recent. 31 to 90 days: verified. Older: may be outdated. */
export function freshness(lastVerified: string, now: Date = new Date()): { level: Freshness; days: number } {
  const days = Math.max(0, Math.floor((now.getTime() - new Date(lastVerified).getTime()) / DAY));
  return { days, level: days <= 30 ? "recent" : days <= 90 ? "verified" : "outdated" };
}

export function formatVerifiedDate(lastVerified: string, lang: "de" | "en"): string {
  return new Date(lastVerified).toLocaleDateString(lang === "de" ? "de-CH" : "en-GB", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}
