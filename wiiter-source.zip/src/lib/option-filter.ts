import type { ActionType, DirectoryCategory, DirectoryItem, ItemCategory, OptionEntry } from "@/data/types";

export interface OptionFilters {
  q?: string | undefined;
  action?: ActionType | undefined;
  item?: ItemCategory | undefined;
  category?: DirectoryCategory | undefined;
  directoryItem?: DirectoryItem | undefined;
  free?: boolean | undefined;
  appointmentRequired?: boolean | undefined;
  acceptsDamaged?: boolean | undefined;
  pickupAvailable?: boolean | undefined;
}

export function filterOptions(data: OptionEntry[], filters: OptionFilters, translate: (text: string) => string = (text) => text) {
  const term = (filters.q ?? "").trim().toLocaleLowerCase();
  return data.filter((option) =>
    (!filters.action || option.actionType === filters.action) &&
    (!filters.item || option.itemCategory.includes(filters.item)) &&
    (!filters.category || (option.directoryCategories ?? [option.actionType]).includes(filters.category)) &&
    (!filters.directoryItem || option.directoryItems?.includes(filters.directoryItem)) &&
    (!filters.free || option.free === true) &&
    (!filters.appointmentRequired || option.appointmentRequired === true) &&
    (!filters.acceptsDamaged || option.acceptsDamaged === true) &&
    (!filters.pickupAvailable || option.pickupAvailable === true) &&
    (!term || [option.title, option.description, option.eligibilityNotes, option.location ?? "", ...(option.directoryItems ?? [])].flatMap((text) => [text, translate(text)]).join(" ").toLocaleLowerCase().includes(term)),
  );
}