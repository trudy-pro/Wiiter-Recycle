import { describe, expect, it } from "vitest";
import { freshness, formatVerifiedDate, prettyGoodSources } from "./sources";

describe("source freshness", () => {
  const now = new Date("2026-10-25T12:00:00Z");
  it("flags 0 to 30 days as verified recently", () => {
    expect(freshness("2026-10-18", now)).toEqual({ days: 7, level: "recent" });
    expect(freshness("2026-09-25", now).level).toBe("recent");
  });
  it("flags 31 to 90 days as verified", () => {
    expect(freshness("2026-09-24", now).level).toBe("verified");
    expect(freshness("2026-07-27", now).level).toBe("verified");
  });
  it("flags anything older than 90 days as may be outdated", () => {
    expect(freshness("2026-07-26", now).level).toBe("outdated");
    expect(freshness("2025-01-01", now).level).toBe("outdated");
  });
  it("formats the verification date for both languages", () => {
    expect(formatVerifiedDate("2026-10-18", "en")).toBe("18 October 2026");
    expect(formatVerifiedDate("2026-10-18", "de")).toBe("18. Oktober 2026");
  });
  it("stores verification dates in structured source data", () => {
    for (const s of prettyGoodSources) {
      expect(s.lastVerified).toMatch(/^\d{4}-\d{2}-\d{2}$/);
      expect(s.sourceUrl).toMatch(/^https:\/\//);
    }
  });
});
