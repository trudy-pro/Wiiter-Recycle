import type { ItemCategory } from "@/data/types";
import type { OutcomeRecord } from "./store";

// Illustrative demonstration values only — not measured data.
export const KG_PER_ITEM: Record<ItemCategory, number> = { electrical: 1.5, textiles: 0.5, tool: 1, other: 1 };
export const CO2_KG_PER_KG = 2; // illustrative average, not a verified factor
export const VALUE_CHF_PER_SOLD = 25; // illustrative average resale value

export function estimateKg(outcomes: OutcomeRecord[]) {
  return outcomes.filter((o) => o.outcome !== "unresolved").reduce((s, o) => s + KG_PER_ITEM[o.item], 0);
}

export function secondLifeCount(outcomes: OutcomeRecord[]) {
  return outcomes.filter((o) => o.outcome === "reused" || o.outcome === "donated" || o.outcome === "sold").length;
}

export function estimateCo2(outcomes: OutcomeRecord[]) {
  return estimateKg(outcomes) * CO2_KG_PER_KG;
}

export function estimateValueChf(outcomes: OutcomeRecord[]) {
  return outcomes.filter((o) => o.outcome === "sold").length * VALUE_CHF_PER_SOLD;
}
