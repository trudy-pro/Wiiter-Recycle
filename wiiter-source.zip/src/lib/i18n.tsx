import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { de } from "./translations";

export type Lang = "en" | "de";
const STORAGE_KEY = "scb-lang";

interface LanguageState {
  lang: Lang;
  setLang: (lang: Lang) => void;
}

const LanguageContext = createContext<LanguageState>({ lang: "en", setLang: () => {} });

/**
 * Client-side DE/EN switch. English is the source language: components render
 * English strings and pass them through t(), which swaps in German when the
 * user picks DE. The choice persists in localStorage with a memory fallback;
 * the stored value is applied after hydration, so SSR always renders English.
 */
export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("en");

  useEffect(() => {
    try {
      const stored = window.localStorage.getItem(STORAGE_KEY);
      if (stored === "de" || stored === "en") setLangState(stored);
    } catch {
      // localStorage unavailable — keep English.
    }
  }, []);

  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);

  const setLang = (next: Lang) => {
    setLangState(next);
    try {
      window.localStorage.setItem(STORAGE_KEY, next);
    } catch {
      // Memory fallback: the choice lives for this session only.
    }
  };

  return <LanguageContext.Provider value={{ lang, setLang }}>{children}</LanguageContext.Provider>;
}

export function useLanguage(): LanguageState {
  return useContext(LanguageContext);
}

export function useT() {
  const { lang } = useLanguage();
  return (s: string) => (lang === "de" ? de[s] ?? s : s);
}
