import type { ActionType, CompleteAnswers } from "@/data/types";
import { itemLabels, conditionLabels } from "@/data/labels";

export type PrettyGoodFit = "likely" | "possible" | "unlikely";

export interface PrettyGoodAssessment {
  fit: PrettyGoodFit;
  confidence: number;
  reasons: string[];
  reusePotential: "High" | "Medium" | "Low";
  alternative: ActionType | "unsure";
  alternativeMessage: string;
}

export interface PrettyGoodLocation {
  id: string;
  name: string;
  address: string;
  hours: string;
  mapsQuery: string;
  lastVerified: string; // ISO date
}

/** Demo collection points. Replace with live municipal data later. */
export const prettyGoodLocations: PrettyGoodLocation[] = [
  { id: "lottner", name: "Lottner AG", address: "Address to be confirmed", hours: "Opening hours to be confirmed", mapsQuery: "Lottner AG Basel", lastVerified: "2026-10-18" },
  { id: "riehen", name: "Werkhof / Recyclingpark Riehen", address: "Address to be confirmed", hours: "Opening hours to be confirmed", mapsQuery: "Recyclingpark Riehen", lastVerified: "2026-10-18" },
];

export function mapsUrl(location: PrettyGoodLocation): string {
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(location.mapsQuery)}`;
}

const alternativeMessages: Record<ActionType | "unsure", string> = {
  repair: "This looks repairable. Repairing it may extend its life.",
  donate: "This appears reusable and may be suitable for donation.",
  recycle: "This item appears too damaged for reuse. Recycling is likely the better route.",
  unsure: "We're not confident enough to recommend a route. Please check with the collection point.",
  resell: "This appears reusable and may be suitable for donation.",
  reuse: "This appears reusable and may be suitable for donation.",
  borrow: "This appears reusable and may be suitable for donation.",
};

/**
 * Transparent, rule based Pretty Good Basel eligibility.
 * Never guarantees acceptance: final acceptance happens at the collection point.
 */
export function assessPrettyGood(a: CompleteAnswers): PrettyGoodAssessment {
  const usable = a.condition === "works" || a.condition === "damaged";

  if (a.item === "textiles") {
    return {
      fit: "unlikely",
      confidence: 25,
      reasons: ["Textiles are not part of the Pretty Good range"],
      reusePotential: usable ? "Medium" : "Low",
      alternative: usable ? "donate" : "recycle",
      alternativeMessage: usable ? alternativeMessages.donate : alternativeMessages.recycle,
    };
  }

  if (a.condition === "broken") {
    return {
      fit: "unlikely",
      confidence: 20,
      reasons: ["Severe damage makes reuse unlikely", "Essential parts may be missing"],
      reusePotential: "Low",
      alternative: a.item === "electrical" ? "recycle" : "repair",
      alternativeMessage: a.item === "electrical" ? alternativeMessages.recycle : alternativeMessages.repair,
    };
  }

  if (a.condition === "unsure") {
    return {
      fit: "possible",
      confidence: 45,
      reasons: ["Category accepted by Pretty Good", "Condition is unclear"],
      reusePotential: "Medium",
      alternative: "unsure",
      alternativeMessage: alternativeMessages.unsure,
    };
  }

  if (a.item === "electrical" || a.item === "tool") {
    const reasons = ["Category accepted by Pretty Good", "Item appears functional", "Strong reuse potential"];
    if (a.condition === "damaged") reasons.splice(2, 0, "Damage looks cosmetic");
    return {
      fit: "likely",
      confidence: a.condition === "works" ? 85 : 78,
      reasons,
      reusePotential: "High",
      alternative: "repair",
      alternativeMessage: alternativeMessages.repair,
    };
  }

  // Other household objects: some are accepted, so stay cautious.
  return {
    fit: "possible",
    confidence: 60,
    reasons: ["Some household objects are accepted", "Item appears complete"],
    reusePotential: usable ? "Medium" : "Low",
    alternative: "donate",
    alternativeMessage: alternativeMessages.donate,
  };
}

export const fitLabels: Record<PrettyGoodFit, string> = {
  likely: "Likely suitable",
  possible: "Possibly suitable",
  unlikely: "Probably not suitable for Pretty Good",
};

export function describeAnswers(a: CompleteAnswers) {
  return { item: itemLabels[a.item], condition: conditionLabels[a.condition] };
}
