import { describe, expect, it } from "vitest";
import { isComplete, recommend, scoreRoutes } from "./engine";

describe("recommendation engine", () => {
  it("requires all four assessment answers before a recommendation", () => {
    const answers = { item: "electrical", condition: "damaged", priority: "repair", transport: "transit" } as const;
    for (const key of ["item", "condition", "priority", "transport"] as const) {
      expect(isComplete({ ...answers, [key]: undefined })).toBe(false);
    }
    expect(isComplete(answers)).toBe(true);
    expect(recommend(answers)?.primary.action).toBe("repair");
  });
  it("shows sourced repair places matching the assessment item, not examples", () => {
    const result = recommend({ item: "electrical", condition: "damaged", priority: "repair", transport: "transit" });
    expect(result?.providers.map((p) => p.id)).toEqual(["basel-reparierbar", "repair-directory"]);
  });
  it("never suggests donating or reselling a broken item", () => {
    const routes = scoreRoutes({ item: "tool", condition: "broken", priority: "second-life", transport: "car" });
    expect(routes.map((r) => r.action)).not.toContain("donate");
    expect(routes.map((r) => r.action)).not.toContain("resell");
  });

  it("never suggests donating or reselling an item of unsure condition", () => {
    const routes = scoreRoutes({ item: "other", condition: "unsure", priority: "convenient", transport: "collection" });
    expect(routes.map((r) => r.action)).not.toContain("donate");
    expect(routes.map((r) => r.action)).not.toContain("resell");
  });

  it("explains recycling for broken electrical items", () => {
    const r = recommend({ item: "electrical", condition: "broken", priority: "convenient", transport: "car" })!;
    expect(r.primary.action).toBe("recycle");
    expect(r.notes.join(" ")).toMatch(/recycling/);
  });

  it("recommends repair when the user asks for repair", () => {
    const r = recommend({ item: "textiles", condition: "damaged", priority: "repair", transport: "walk" })!;
    expect(r.primary.action).toBe("repair");
  });

  it("changes recommendation with answers", () => {
    const r = recommend({ item: "textiles", condition: "works", priority: "second-life", transport: "walk" })!;
    expect(["donate", "reuse"]).toContain(r.primary.action);
  });
});
