import { options } from "@/data/options";
import type { ActionType, Answers, CompleteAnswers, OptionEntry } from "@/data/types";

export interface Route {
  action: ActionType;
  score: number;
  reasons: string[];
}

export interface Recommendation {
  primary: Route;
  alternatives: Route[];
  checklist: string[];
  verifyQuestions: string[];
  notes: string[];
  providers: OptionEntry[];
}

const CANDIDATES: ActionType[] = ["repair", "donate", "resell", "reuse", "recycle"];

export function isComplete(a: Answers): a is CompleteAnswers {
  return !!(a.item && a.condition && a.priority && a.transport);
}

/** Deterministic, rule-based scoring. Every point added carries a human-readable reason. */
export function scoreRoutes(a: CompleteAnswers): Route[] {
  const routes = new Map<ActionType, Route>(
    CANDIDATES.map((action) => [action, { action, score: 0, reasons: [] }]),
  );
  const add = (action: ActionType, pts: number, reason?: string) => {
    const r = routes.get(action)!;
    r.score += pts;
    if (reason && pts > 0) r.reasons.push(reason);
  };
  const usable = a.condition === "works" || a.condition === "damaged";

  switch (a.condition) {
    case "works":
      add("donate", 3, "It works, so someone else can use it as it is.");
      add("resell", 3, "Working items are easy to pass on or sell.");
      add("reuse", 2, "A working item can be reused directly.");
      break;
    case "damaged":
      add("repair", 3, "It is damaged, and a small fix could extend its life.");
      add("reuse", 2, "It is still usable, so it can be reused.");
      add("resell", 1, "It can be passed on if the damage is described honestly.");
      add("donate", 1, "Some places accept usable items with minor wear.");
      add("recycle", 1);
      break;
    case "broken":
      add("repair", 3, "It is broken, so repair is the way to keep it in use.");
      add("recycle", 2, "If repair is not possible, materials can be recovered.");
      if (a.item === "textiles") add("reuse", 2, "Fabric from broken textiles can be reused as material.");
      else if (a.item !== "electrical") add("reuse", 1, "Parts or materials may be reusable.");
      break;
    case "unsure":
      add("repair", 3, "Its condition is unclear — a repair check tells you what is possible.");
      add("reuse", 1, "If it turns out to work, it can be reused.");
      add("recycle", 1);
      break;
  }

  switch (a.priority) {
    case "second-life":
      add("repair", 1, "Repair keeps the item itself in use.");
      if (usable) {
        add("donate", 2, "You want it to have a second life.");
        add("reuse", 2, "You want it to have a second life.");
      }
      break;
    case "cheap":
      add("repair", 1, "Community repair is often low cost.");
      if (usable) add("resell", 2, "Selling can even earn you a little money.");
      add("reuse", 1, "Reuse costs nothing.");
      add("recycle", 1, "Many recycling routes are free.");
      break;
    case "convenient":
      add("recycle", 2, "You want a convenient way to hand it on.");
      if (usable) add("donate", 2, "Donating is a quick, single drop off.");
      break;
    case "repair":
      add("repair", 4, "You asked for a repair option.");
      break;
  }

  switch (a.transport) {
    case "collection":
      add("resell", 1, "Buyers often collect items themselves.");
      add("recycle", 1, "Some recycling routes offer collection.");
      add("repair", -1);
      break;
    case "walk":
      add("reuse", 1, "Reuse can happen close to home.");
      break;
    case "car":
      add("recycle", 1, "With a car, reaching a recycling point is easy.");
      add("donate", 1, "With a car, dropping off a donation is easy.");
      break;
    case "transit":
      break;
  }

  if (a.item === "electrical" && a.condition === "broken") {
    add("recycle", 1, "Electrical items contain materials that need proper recycling.");
  }

  // Hard rule: never recommend donating or reselling a broken or unverified item.
  if (!usable) {
    routes.delete("donate");
    routes.delete("resell");
  }
  // Electrical items cannot reasonably go to reuse as raw material.
  if (a.item === "electrical" && !usable) routes.delete("reuse");

  return [...routes.values()]
    .filter((r) => r.score > 0)
    .sort((x, y) => y.score - x.score || CANDIDATES.indexOf(x.action) - CANDIDATES.indexOf(y.action));
}

const checklists: Record<ActionType, string[]> = {
  repair: [
    "Write down what is wrong and when it started.",
    "Bring the item, its cable, charger or missing parts.",
    "Ask for a cost estimate before any paid work.",
    "Compare repair cost with the value of the item.",
  ],
  donate: [
    "Clean the item and check it is complete.",
    "Confirm the organisation currently accepts this type of item.",
    "Drop it off during opening hours.",
  ],
  resell: [
    "Take clear photos in daylight.",
    "Describe the condition honestly, including any defects.",
    "Agree a safe place and time for handover.",
  ],
  reuse: [
    "Decide whether to reuse it yourself or offer it to a neighbour.",
    "Clean it and remove personal items or data.",
    "Offer it through a giveaway box or local group.",
  ],
  borrow: ["Check membership terms.", "Ask whether working items are accepted."],
  recycle: [
    "Remove batteries and separate materials where possible.",
    "Check the official city guidance for this material.",
    "Bring it to an appropriate collection point.",
  ],
};

const verifyQuestions: Record<ActionType, string[]> = {
  repair: ["Do you repair this type of item?", "What are the opening hours or next event date?", "Is there a fee for diagnosis?"],
  donate: ["Do you currently accept this item type?", "What condition must it be in?", "What are your opening hours?"],
  resell: ["Is there a fee for listing?", "Who handles pickup or delivery?"],
  reuse: ["Is the giveaway spot currently accepting items?", "Are there size limits?"],
  borrow: ["Do you accept donated items?", "What are your opening hours?"],
  recycle: ["Is this material accepted here?", "What are the opening hours?", "Are there disposal fees?"],
};

export function recommend(a: CompleteAnswers, data: OptionEntry[] = options): Recommendation | null {
  const ranked = scoreRoutes(a);
  if (ranked.length === 0) return null;
  const primary = ranked[0]!;
  const rest = ranked.slice(1);
  const notes: string[] = [];
  if (a.item === "electrical" && a.condition === "broken") {
    notes.push(
      "If a repair check shows the item cannot reasonably be fixed, appropriate electrical recycling is the next step. Do not put electrical items in household waste.",
    );
  }
  if (a.condition === "unsure") {
    notes.push("Until you know it works, don't donate or sell it — test it or have it checked first.");
  }
  if (a.condition === "damaged") {
    notes.push("If you pass it on, clearly mention the damage.");
  }
  const providers = data.filter(
    (o) => (o.verificationStatus === "verified" || o.verificationStatus === "official") && o.sourceUrl && o.actionType === primary.action && o.itemCategory.includes(a.item),
  );
  return {
    primary,
    alternatives: rest.slice(0, 2),
    checklist: checklists[primary.action],
    verifyQuestions: verifyQuestions[primary.action],
    notes,
    providers,
  };
}
