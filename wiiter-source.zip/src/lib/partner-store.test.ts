import { beforeEach, describe, expect, it } from "vitest";
import { canEdit, canManageSettings, canVerify, dataFreshness, partnerActions, usePartnerState } from "./partner-store";
import { renderHook } from "@testing-library/react";

function getState() {
  const { result } = renderHook(() => usePartnerState());
  return result.current;
}

describe("partner store", () => {
  beforeEach(() => {
    window.localStorage.clear();
    partnerActions.resetDemo();
    partnerActions.setOrg("pretty-good");
  });

  it("marks a location as verified today and records history", () => {
    const before = getState();
    const target = before.locations.find((l) => l.id === "aeschenplatz")!;
    expect(target.status).toBe("Outdated");
    partnerActions.verifyLocation("aeschenplatz");
    const after = getState();
    const updated = after.locations.find((l) => l.id === "aeschenplatz")!;
    expect(updated.status).toBe("Verified");
    expect(updated.lastVerified).toBe(new Date().toISOString().slice(0, 10));
    expect(after.history[0]?.newValue).toBe("Verified");
    expect(after.history.length).toBe(before.history.length + 1);
  });

  it("records category status changes in the audit log", () => {
    partnerActions.updateCategory("cat-electronics", { status: "Accepted" });
    const after = getState();
    expect(after.categories.find((c) => c.id === "cat-electronics")?.status).toBe("Accepted");
    expect(after.history[0]?.oldValue).toBe("Conditionally accepted");
    expect(after.history[0]?.newValue).toBe("Accepted");
  });

  it("resolves user reports", () => {
    partnerActions.setReportStatus("rep-1", "Resolved");
    expect(getState().reports.find((r) => r.id === "rep-1")?.status).toBe("Resolved");
  });

  it("computes a data freshness score per organization", () => {
    const score = dataFreshness(getState(), new Date("2026-10-25T12:00:00Z"));
    // pretty-good: 3 active locations (2 recent) + 4 rules (3 recent) = 5/7
    expect(score.locationsTotal).toBe(3);
    expect(score.locationsRecent).toBe(2);
    expect(score.rulesRecent).toBe(3);
    expect(score.score).toBe(71);
    expect(score.openReports).toBe(2);
  });

  it("gates actions by role", () => {
    expect(canEdit("Admin")).toBe(true);
    expect(canEdit("Editor")).toBe(true);
    expect(canEdit("Verifier")).toBe(false);
    expect(canVerify("Verifier")).toBe(true);
    expect(canVerify("Viewer")).toBe(false);
    expect(canManageSettings("Admin")).toBe(true);
    expect(canManageSettings("Editor")).toBe(false);
  });
});
