import { useSyncExternalStore } from "react";
import {
  demoCategories, demoHistory, demoLocations, demoReports, demoRules, partnerOrgs,
  type HistoryEvent, type PartnerCategory, type PartnerLocation, type PartnerRole, type ReportStatus, type RoutingRule, type UserReport,
} from "@/data/partner";
import { freshness } from "@/lib/sources";

interface PartnerState {
  orgId: string;
  role: PartnerRole;
  locations: PartnerLocation[];
  categories: PartnerCategory[];
  rules: RoutingRule[];
  reports: UserReport[];
  history: HistoryEvent[];
}

const KEY = "scb-partner-v1";
const EMPTY: PartnerState = {
  orgId: partnerOrgs[0]!.id,
  role: "Admin",
  locations: demoLocations,
  categories: demoCategories,
  rules: demoRules,
  reports: demoReports,
  history: demoHistory,
};
let state: PartnerState = EMPTY;
let loaded = false;
const listeners = new Set<() => void>();

function load() {
  if (loaded || typeof window === "undefined") return;
  loaded = true;
  try {
    const raw = window.localStorage.getItem(KEY);
    if (raw) state = { ...EMPTY, ...JSON.parse(raw) };
  } catch {
    /* demo data only */
  }
}

function set(next: PartnerState) {
  state = next;
  try {
    window.localStorage.setItem(KEY, JSON.stringify(state));
  } catch {
    /* memory only */
  }
  listeners.forEach((l) => l());
}

function subscribe(l: () => void) {
  load();
  listeners.add(l);
  l();
  return () => listeners.delete(l);
}

export function usePartnerState(): PartnerState {
  return useSyncExternalStore(subscribe, () => state, () => EMPTY);
}

const today = () => new Date().toISOString().slice(0, 10);

function record(change: string, oldValue: string, newValue: string): HistoryEvent {
  const org = partnerOrgs.find((o) => o.id === state.orgId);
  return {
    id: crypto.randomUUID(),
    orgId: state.orgId,
    date: today(),
    user: `Demo user — ${org?.name ?? "Partner"}`,
    change,
    oldValue,
    newValue,
  };
}

export function canEdit(role: PartnerRole): boolean {
  return role === "Admin" || role === "Editor";
}

export function canVerify(role: PartnerRole): boolean {
  return role === "Admin" || role === "Editor" || role === "Verifier";
}

export function canManageSettings(role: PartnerRole): boolean {
  return role === "Admin";
}

export const partnerActions = {
  setOrg(orgId: string) {
    set({ ...state, orgId });
  },
  setRole(role: PartnerRole) {
    set({ ...state, role });
  },
  updateLocation(id: string, patch: Partial<PartnerLocation>, changeLabel: string) {
    const loc = state.locations.find((l) => l.id === id);
    if (!loc) return;
    const event = record(changeLabel, loc.status, "Updated");
    set({
      ...state,
      locations: state.locations.map((l) => (l.id === id ? { ...l, ...patch } : l)),
      history: [event, ...state.history],
    });
  },
  verifyLocation(id: string) {
    const loc = state.locations.find((l) => l.id === id);
    if (!loc) return;
    const event = record(loc.name, loc.status, "Verified");
    set({
      ...state,
      locations: state.locations.map((l) => (l.id === id ? { ...l, lastVerified: today(), status: "Verified" } : l)),
      history: [event, ...state.history],
    });
  },
  updateCategory(id: string, patch: Partial<PartnerCategory>) {
    const cat = state.categories.find((c) => c.id === id);
    if (!cat) return;
    const event = record(cat.category, cat.status, patch.status ?? cat.status);
    set({
      ...state,
      categories: state.categories.map((c) => (c.id === id ? { ...c, ...patch } : c)),
      history: [event, ...state.history],
    });
  },
  verifyCategory(id: string) {
    const cat = state.categories.find((c) => c.id === id);
    if (!cat) return;
    const event = record(cat.category, cat.verificationStatus, "Verified");
    set({
      ...state,
      categories: state.categories.map((c) => (c.id === id ? { ...c, lastVerified: today(), verificationStatus: "Verified" } : c)),
      history: [event, ...state.history],
    });
  },
  updateRule(id: string, patch: Partial<RoutingRule>) {
    const rule = state.rules.find((r) => r.id === id);
    if (!rule) return;
    const event = record(`Rule ${rule.code}`, rule.status, patch.status ?? "Updated");
    set({
      ...state,
      rules: state.rules.map((r) => (r.id === id ? { ...r, ...patch } : r)),
      history: [event, ...state.history],
    });
  },
  verifyRule(id: string) {
    const rule = state.rules.find((r) => r.id === id);
    if (!rule) return;
    const event = record(`Rule ${rule.code}`, rule.status, "Verified");
    set({
      ...state,
      rules: state.rules.map((r) => (r.id === id ? { ...r, lastVerified: today(), status: "Verified" } : r)),
      history: [event, ...state.history],
    });
  },
  setReportStatus(id: string, status: ReportStatus) {
    const report = state.reports.find((r) => r.id === id);
    if (!report) return;
    const event = record(`Report: ${report.type}`, report.status, status);
    set({
      ...state,
      reports: state.reports.map((r) => (r.id === id ? { ...r, status } : r)),
      history: [event, ...state.history],
    });
  },
  resetDemo() {
    set({ ...EMPTY, orgId: state.orgId, role: state.role });
  },
};

export interface FreshnessScore {
  score: number;
  locationsRecent: number;
  locationsTotal: number;
  rulesRecent: number;
  rulesTotal: number;
  hoursRecent: number;
  hoursTotal: number;
  openReports: number;
}

/** Share of partner data verified within the last 30 days. */
export function dataFreshness(s: PartnerState, now: Date = new Date()): FreshnessScore {
  const locations = s.locations.filter((l) => l.orgId === s.orgId && l.active);
  const rules = s.rules.filter((r) => r.orgId === s.orgId);
  const recent = (date: string) => freshness(date, now).days <= 30;
  const locationsRecent = locations.filter((l) => recent(l.lastVerified)).length;
  const rulesRecent = rules.filter((r) => recent(r.lastVerified)).length;
  const hoursRecent = locations.filter((l) => recent(l.lastVerified) && l.hours).length;
  const total = locations.length + rules.length;
  return {
    score: total === 0 ? 0 : Math.round(((locationsRecent + rulesRecent) / total) * 100),
    locationsRecent,
    locationsTotal: locations.length,
    rulesRecent,
    rulesTotal: rules.length,
    hoursRecent,
    hoursTotal: locations.length,
    openReports: s.reports.filter((r) => r.orgId === s.orgId && r.status === "Open").length,
  };
}
