import { describe, expect, it } from "vitest";
import type { OutcomeRecord } from "./store";
import { estimateKg, estimateCo2, estimateValueChf, secondLifeCount, KG_PER_ITEM, CO2_KG_PER_KG, VALUE_CHF_PER_SOLD } from "./impact";
import { impactExamples } from "../data/impact-examples";

function rec(partial: Partial<OutcomeRecord>): OutcomeRecord {
  return { id: partial.id ?? "x", item: partial.item ?? "other", action: partial.action ?? "donate", outcome: partial.outcome ?? "donated", date: partial.date ?? "2026-01-01" };
}

describe("impact estimates", () => {
  it("counts only reused, donated and sold as second life", () => {
    const outcomes = [
      rec({ outcome: "reused" }),
      rec({ outcome: "donated" }),
      rec({ outcome: "sold" }),
      rec({ outcome: "recycled" }),
      rec({ outcome: "repaired" }),
      rec({ outcome: "unresolved" }),
    ];
    expect(secondLifeCount(outcomes)).toBe(3);
  });

  it("sums illustrative kg per resolved item", () => {
    const outcomes = [rec({ item: "electrical", outcome: "recycled" }), rec({ item: "textiles", outcome: "donated" }), rec({ outcome: "unresolved" })];
    expect(estimateKg(outcomes)).toBeCloseTo(KG_PER_ITEM.electrical + KG_PER_ITEM.textiles);
  });

  it("estimates CO₂ as kg times the illustrative factor", () => {
    const outcomes = [rec({ item: "other", outcome: "donated" })];
    expect(estimateCo2(outcomes)).toBeCloseTo(KG_PER_ITEM.other * CO2_KG_PER_KG);
  });

  it("estimates value only from resold items", () => {
    const outcomes = [rec({ outcome: "sold" }), rec({ outcome: "sold" }), rec({ outcome: "donated" })];
    expect(estimateValueChf(outcomes)).toBe(2 * VALUE_CHF_PER_SOLD);
  });
});

describe("impact example rows", () => {
  it("shows the brief's example items with their stated values", () => {
    expect(impactExamples.map((e) => `${e.item} — ${e.action}`)).toEqual([
      "Old chair — Given away",
      "Laptop — Recycled",
      "Jacket — Resold",
    ]);
    expect(impactExamples[0]?.detail).toBe("1 item given a second life · Approx. 8 kg waste avoided");
    expect(impactExamples[1]?.detail).toBe("Electronics recycled responsibly · Approx. 4 kg waste avoided");
    expect(impactExamples[2]?.detail).toBe("Item reused · CHF 25 value recovered");
    expect(impactExamples.map((e) => e.tag)).toEqual(["Donated", "Recycled", "Resold"]);
  });

  it("keeps example rows out of the counted totals", () => {
    expect(secondLifeCount([])).toBe(0);
    expect(estimateKg([])).toBe(0);
    expect(estimateCo2([])).toBe(0);
    expect(estimateValueChf([])).toBe(0);
  });
});
