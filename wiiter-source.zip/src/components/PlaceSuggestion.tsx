import { useState } from "react";
import { Download, Plus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { directoryLabels } from "@/data/directory-labels";
import { useT } from "@/lib/i18n";

export function PlaceSuggestion({ initiallyOpen = false }: { initiallyOpen?: boolean }) {
  const t = useT();
  const [open, setOpen] = useState(initiallyOpen);
  const [downloaded, setDownloaded] = useState(false);
  return <section className="mt-10 border-t pt-6">
    <div className="flex flex-wrap items-center justify-between gap-3"><h2 className="font-medium">{t("Know a place we should add?")}</h2><Button variant="ghost" onClick={() => setOpen(!open)} aria-expanded={open}>{open ? <X /> : <Plus />}{t("Suggest a place")}</Button></div>
    {open && <form className="mt-5 max-w-xl space-y-4" onSubmit={(event) => {
      event.preventDefault();
      const fields = Object.fromEntries(new FormData(event.currentTarget));
      const url = URL.createObjectURL(new Blob([JSON.stringify(fields, null, 2)], { type: "application/json" }));
      const link = document.createElement("a"); link.href = url; link.download = "basel-place-suggestion.json"; link.click(); URL.revokeObjectURL(url); setDownloaded(true);
    }}>
      <p className="text-sm text-muted-foreground">{t("Suggestions are saved as a file on your device, not submitted or published.")}</p>
      <label className="block space-y-1 text-sm"><span>{t("Organisation name")}</span><Input name="name" required maxLength={150} /></label>
      <label className="block space-y-1 text-sm"><span>{t("Category")}</span><select name="category" className="w-full rounded-md border bg-card px-3 py-2">{Object.entries(directoryLabels).map(([key, label]) => <option value={key} key={key}>{t(label)}</option>)}</select></label>
      <label className="block space-y-1 text-sm"><span>{t("Website")}</span><Input name="website" type="url" placeholder="https://" /></label>
      <label className="block space-y-1 text-sm"><span>{t("Address")}</span><Input name="address" maxLength={250} /></label>
      <label className="block space-y-1 text-sm"><span>{t("Short note")}</span><Textarea name="note" maxLength={1000} /></label>
      <Button type="submit" className="btn btn-primary h-auto whitespace-normal"><Download />{t("Download suggestion")}</Button>
      {downloaded && <p role="status" className="text-sm text-accent-foreground">{t("Suggestion downloaded. It has not been submitted.")}</p>}
    </form>}
  </section>;
}