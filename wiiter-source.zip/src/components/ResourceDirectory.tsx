import { ExternalLink, Heart, Recycle, Tag, Wrench } from "lucide-react";
import { resourceGroups } from "@/data/resource-groups";
import { useT } from "@/lib/i18n";

const categoryIcons = { repair: Wrench, donate: Heart, sell: Tag, recycle: Recycle };

export function ResourceDirectory() {
  const t = useT();
  return <div className="container-page max-w-5xl pt-12 md:pt-16">
    <h1 className="text-4xl font-semibold leading-tight text-directory-heading md:text-5xl">{t("Places in Basel")}</h1>
    <p className="mt-4 text-lg text-muted-foreground">{t("From repair to disposal — best from top to bottom.")}</p>
    <div className="mt-12 space-y-12 md:mt-14 md:space-y-14">
      {resourceGroups.map((group) => {
        const Icon = categoryIcons[group.id];
        return <section key={group.id} aria-labelledby={`resources-${group.id}`}>
          <h2 id={`resources-${group.id}`} className="flex items-center gap-3 text-2xl font-semibold text-directory-heading"><Icon className="h-6 w-6 shrink-0 text-directory-icon" strokeWidth={1.75} aria-hidden />{t(group.title)}</h2>
          <ul className="mt-5 grid auto-rows-fr gap-4 md:grid-cols-2">
            {group.cards.map((card) => <li key={card.name} className="min-w-0">
              <a href={card.href} target="_blank" rel="noreferrer" className="group grid h-full min-h-36 grid-cols-[minmax(0,1fr)_auto] items-start gap-4 rounded-xl border border-input/70 bg-transparent p-6 transition-colors hover:border-directory-heading/50 hover:bg-accent/30 focus-visible:border-directory-heading focus-visible:bg-accent/30">
                <div className="min-w-0"><h3 className="text-lg font-semibold leading-snug text-directory-heading">{t(card.name)}</h3><p className="mt-2 text-base leading-relaxed text-muted-foreground">{t(card.description)}</p></div>
                <ExternalLink className="mt-1 h-4 w-4 shrink-0 text-muted-foreground transition-colors group-hover:text-directory-heading" strokeWidth={1.75} aria-hidden />
              </a>
            </li>)}
          </ul>
        </section>;
      })}
    </div>
    <p className="mt-8 text-sm text-muted-foreground">{t("Check accepted items and current opening times before visiting.")}</p>
  </div>;
}