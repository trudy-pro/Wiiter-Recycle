import { useState } from "react";
import { BadgeCheck, ExternalLink, Flag } from "lucide-react";
import { useLanguage, useT } from "@/lib/i18n";
import { formatVerifiedDate, freshness, freshnessLabels, sourceTypeLabels, type SourceInfo } from "@/lib/sources";
import { trackPilotEvent } from "@/lib/pilot";

const outdatedReasons = ["Opening hours", "Address", "Item eligibility", "Service no longer available", "Contact information", "Other"] as const;

export function FreshnessLine({ lastVerified }: { lastVerified: string }) {
  const t = useT();
  const { lang } = useLanguage();
  const f = freshness(lastVerified);
  return <p className="mt-2 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
    <span>{t("Last verified")}: {formatVerifiedDate(lastVerified, lang)}</span>
    <span className={`rounded-full px-2 py-0.5 font-medium ${f.level === "outdated" ? "bg-warning text-warning-foreground" : "bg-accent text-accent-foreground"}`}>
      {t(freshnessLabels[f.level])}
    </span>
  </p>;
}

export function ReportOutdated({ target }: { target: string }) {
  const t = useT();
  const [open, setOpen] = useState(false);
  const [sent, setSent] = useState(false);
  if (sent) return <p className="mt-3 text-xs text-muted-foreground">{t("Thanks, we recorded your report.")}</p>;
  if (!open) return <button type="button" onClick={() => setOpen(true)} className="mt-3 inline-flex items-center gap-1.5 text-xs text-muted-foreground underline-offset-4 hover:underline">
    <Flag className="h-3 w-3" aria-hidden />{t("Report outdated info")}
  </button>;
  return <div className="mt-3 rounded-lg bg-muted/60 p-3">
    <p className="text-xs font-semibold">{t("What appears incorrect?")}</p>
    <div className="mt-2 flex flex-wrap gap-1.5">
      {outdatedReasons.map((reason) => <button key={reason} type="button" onClick={() => { trackPilotEvent("information_reported_outdated", `${target}:${reason}`); setSent(true); }} className="rounded-full border border-input px-2.5 py-1 text-xs hover:border-primary hover:text-primary">
        {t(reason)}
      </button>)}
    </div>
  </div>;
}

export function SourceCards({ sources }: { sources: SourceInfo[] }) {
  const t = useT();
  return <section className="mt-10" aria-labelledby="based-on">
    <h2 className="text-lg font-semibold">{t("Based on")}</h2>
    <ul className="mt-4 grid gap-3 sm:grid-cols-2">
      {sources.map((s) => <li key={s.id} className="rounded-xl border border-border p-5">
        <div className="flex flex-wrap items-center gap-2">
          <h3 className="font-semibold">{t(s.sourceName)}</h3>
          {s.sourceType === "official" && <span className="inline-flex items-center gap-1 rounded-full bg-primary-soft px-2.5 py-0.5 text-xs font-semibold text-accent-foreground">
            <BadgeCheck className="h-3 w-3" aria-hidden />{t("Official source")}
          </span>}
          <span className="inline-flex items-center gap-1 rounded-full bg-lime px-2.5 py-0.5 text-xs font-semibold text-lime-foreground">
            <BadgeCheck className="h-3 w-3" aria-hidden />{t("Partner verified")}
          </span>
        </div>
        <p className="text-sm text-muted-foreground">{t(s.organization)} · {t(sourceTypeLabels[s.sourceType])}</p>
        <p className="mt-1 text-xs text-muted-foreground">{t("Verified by")} {t(s.organization)}</p>
        <p className="mt-2 text-sm">{t(s.description)}</p>
        <FreshnessLine lastVerified={s.lastVerified} />
        <a href={s.sourceUrl} target="_blank" rel="noreferrer" onClick={() => { trackPilotEvent("source_opened", s.id); trackPilotEvent("source_clicked", s.id); }} className="btn btn-outline mt-4 !px-4 !py-2 text-sm">
          {t("View source")}<ExternalLink className="h-3.5 w-3.5" aria-hidden />
        </a>
        <ReportOutdated target={s.id} />
      </li>)}
    </ul>
  </section>;
}
