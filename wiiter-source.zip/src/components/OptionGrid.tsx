import { Link } from "@tanstack/react-router";
import { ArrowUpRight, MapPin, Clock, BadgeCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ActionIcon } from "@/components/ActionIcon";
import { actionLabels } from "@/data/labels";
import { directoryLabels, directoryItemLabels } from "@/data/directory-labels";
import { optionImages } from "@/data/option-images";
import type { OptionEntry } from "@/data/types";
import { useT } from "@/lib/i18n";

export function OptionGrid({ entries, compact = false }: { entries: OptionEntry[]; compact?: boolean }) {
  const t = useT();
  return <ul className={`mt-4 grid gap-4 md:grid-cols-2 ${compact ? "" : "lg:grid-cols-3"}`}>
    {entries.map((o) => <li key={o.id} className="card-civic flex min-w-0 flex-col overflow-hidden fade-up">
      {optionImages[o.id] && <img src={optionImages[o.id]} alt={t(o.title)} loading="lazy" className="h-36 w-full object-cover" />}
      <div className="flex flex-1 flex-col p-5">
        <div className="flex flex-wrap items-center justify-between gap-2"><span className="inline-flex items-center gap-2 text-sm font-medium"><ActionIcon action={o.actionType} className="h-4 w-4 shrink-0" />{t(actionLabels[o.actionType])}</span><span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs ${o.verificationStatus === "example" ? "bg-warning text-warning-foreground" : "bg-accent text-accent-foreground"}`}><BadgeCheck className="h-3 w-3" />{t(o.verificationStatus === "verified" ? "Verified" : o.verificationStatus === "official" ? "Official source" : o.verificationStatus === "community" ? "Community submitted" : "Example")}</span></div>
        <h3 className="mt-4 text-lg font-semibold leading-snug">{t(o.title)}</h3>
        <p className="mt-2 text-sm text-muted-foreground">{t(o.description)}</p>
        <div className="mt-4 space-y-2 text-sm"><p className="flex items-start gap-2"><MapPin className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />{t(o.location ?? "Location not yet verified")}</p><p className="flex items-start gap-2"><Clock className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />{t(o.hours ?? "Hours not yet verified")}</p><p><span className="font-medium">{t("Cost")}: </span>{t(o.cost ?? "Contact provider")}</p></div>
        <div className="mt-4 flex flex-wrap gap-1.5">{(o.directoryItems ?? []).slice(0, 3).map((item) => <span key={item} className="rounded-full bg-muted px-2.5 py-1 text-xs">{t(directoryItemLabels[item])}</span>)}{o.directoryCategories?.includes("events") && <span className="rounded-full bg-accent px-2.5 py-1 text-xs text-accent-foreground">{t(directoryLabels.events)}</span>}</div>
        <div className="mt-auto flex flex-wrap gap-2 pt-5"><Button asChild variant="outline" className="h-auto whitespace-normal rounded-full"><Link to="/places/$placeId" params={{ placeId: o.id }}>{t("View details")}<ArrowUpRight /></Link></Button>{o.address && <Button asChild variant="ghost" className="h-auto whitespace-normal"><a href={`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(o.address)}`} target="_blank" rel="noreferrer">{t("Directions")}<ArrowUpRight /></a></Button>}</div>
      </div>
    </li>)}
  </ul>;
}
