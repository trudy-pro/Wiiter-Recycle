import { Gift, Recycle, RefreshCw, Repeat, Users, Wrench } from "lucide-react";
import type { ActionType } from "@/data/types";

const icons = { repair: Wrench, donate: Gift, resell: Repeat, reuse: RefreshCw, borrow: Users, recycle: Recycle };

export function ActionIcon({ action, className = "h-5 w-5" }: { action: ActionType; className?: string }) {
  const Icon = icons[action];
  return <Icon className={className} aria-hidden />;
}
