import { useT } from "@/lib/i18n";
import type { VerificationStatus } from "@/data/partner";

const styles: Record<VerificationStatus, string> = {
  Verified: "bg-accent text-accent-foreground",
  "Needs review": "bg-warning text-warning-foreground",
  Outdated: "bg-warning text-warning-foreground",
  Draft: "bg-muted text-muted-foreground",
};

export function StatusBadge({ status }: { status: VerificationStatus }) {
  const t = useT();
  return <span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${styles[status]}`}>{t(status)}</span>;
}
