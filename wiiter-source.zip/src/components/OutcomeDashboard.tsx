import { outcomeLabels } from "@/data/labels";
import type { OutcomeType } from "@/data/types";
import type { OutcomeRecord } from "@/lib/store";
import { useT } from "@/lib/i18n";

export function OutcomeDashboard({ outcomes }: { outcomes: OutcomeRecord[] }) {
  const t = useT();
  const resolved = outcomes.filter((o) => o.outcome !== "unresolved").length;
  const keys = Object.keys(outcomeLabels) as OutcomeType[];
  return (
    <div className="grid gap-3 sm:grid-cols-3 lg:grid-cols-4">
      <div className="card-civic bg-primary p-5 text-primary-foreground">
        <p className="text-sm opacity-80">{t("Items resolved")}</p>
        <p className="mt-2 text-4xl font-semibold">{resolved}</p>
        <p className="text-xs opacity-80">{t("of X recorded").replace("X", String(outcomes.length))}</p>
      </div>
      {keys.map((k) => (
        <div key={k} className="card-civic p-5">
          <p className="text-sm text-muted-foreground">{t(outcomeLabels[k])}</p>
          <p className="mt-2 text-3xl font-semibold">{outcomes.filter((o) => o.outcome === k).length}</p>
        </div>
      ))}
    </div>
  );
}
