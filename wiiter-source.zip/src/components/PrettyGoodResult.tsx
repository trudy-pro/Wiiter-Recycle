import { useState } from "react";
import { AlertCircle, Check, ChevronDown, ExternalLink, MapPin } from "lucide-react";
import { useT } from "@/lib/i18n";
import { assessPrettyGood, describeAnswers, fitLabels, mapsUrl, prettyGoodLocations } from "@/lib/prettygood";
import { prettyGoodSources } from "@/lib/sources";
import { trackPilotEvent } from "@/lib/pilot";
import { actionLabels } from "@/data/labels";
import { FreshnessLine, ReportOutdated, SourceCards } from "@/components/SourceCards";
import type { CompleteAnswers } from "@/data/types";

const outcomeOptions = [
  { id: "went", label: "I went there" },
  { id: "accepted", label: "Item was accepted" },
  { id: "rejected", label: "Item was not accepted" },
  { id: "repaired", label: "I repaired it" },
  { id: "donated", label: "I donated it" },
  { id: "recycled", label: "I recycled it" },
  { id: "other", label: "I chose another option" },
  { id: "pending", label: "I haven't acted yet" },
] as const;

const rejectionReasons = ["Wrong item category", "Too damaged", "Missing parts", "Location did not accept it", "Information was outdated", "Other"] as const;

export function PrettyGoodResult({ answers }: { answers: CompleteAnswers }) {
  const t = useT();
  const assessment = assessPrettyGood(answers);
  const detected = describeAnswers(answers);
  const [chosen, setChosen] = useState<string | null>(null);
  const [outcome, setOutcome] = useState<string | null>(null);
  const [rejectionReason, setRejectionReason] = useState<string | null>(null);
  const [rejectionText, setRejectionText] = useState("");
  const [accuracy, setAccuracy] = useState<"yes" | "partly" | "no" | null>(null);
  const [improveText, setImproveText] = useState("");
  const isLikely = assessment.fit === "likely";

  const pickOutcome = (id: string) => {
    setOutcome(id);
    if (id === "pending") return;
    trackPilotEvent("outcome_reported", id);
    if (id === "accepted" || id === "repaired" || id === "donated" || id === "recycled") trackPilotEvent("outcome_accepted", id);
    if (id === "rejected") trackPilotEvent("outcome_rejected", id);
    if (id === "other") trackPilotEvent("recommendation_rejected", id);
    if (id === "accepted") trackPilotEvent("recommendation_accepted", id);
  };

  const pickAccuracy = (value: "yes" | "partly" | "no") => {
    setAccuracy(value);
    trackPilotEvent(value === "yes" ? "recommendation_accuracy_yes" : value === "partly" ? "recommendation_accuracy_partial" : "recommendation_accuracy_no");
    trackPilotEvent(value === "yes" ? "user_feedback_positive" : "user_feedback_negative");
  };

  const lifecycle = [
    { label: "Recommendation", done: true },
    { label: "Destination selected", done: chosen !== null },
    { label: "Outcome reported", done: outcome !== null && outcome !== "pending" },
  ];

  return <div className="container-page max-w-4xl pt-10">
    <section className={`rounded-2xl p-6 md:p-8 ${isLikely ? "bg-accent text-accent-foreground" : "bg-muted"}`} aria-labelledby="pg-title">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 id="pg-title" className="text-2xl font-semibold leading-tight md:text-3xl">
          {isLikely ? t("Give it a second life with Pretty Good Basel") : t(fitLabels[assessment.fit])}
        </h2>
        <span className="rounded-full bg-lime px-3.5 py-1.5 text-sm font-semibold text-lime-foreground">
          {t(fitLabels[assessment.fit])} · {assessment.confidence}%
        </span>
      </div>
      <p className="mt-4 max-w-2xl">
        {t(isLikely
          ? "This item appears suitable for reuse. Pretty Good Basel collects reusable or lightly damaged household items and channels them back into the second hand economy."
          : assessment.alternativeMessage)}
      </p>
      <ul className="mt-5 space-y-2">
        {assessment.reasons.map((r) => <li key={r} className="flex gap-3"><Check className="mt-1 h-4 w-4 shrink-0" aria-hidden />{t(r)}</li>)}
      </ul>
      <p className="mt-5 flex items-start gap-2 rounded-xl bg-warning px-4 py-3 text-sm text-warning-foreground">
        <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
        {t("Final acceptance depends on inspection at the collection point.")}
      </p>
      {isLikely && <a href="#pg-locations" className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full bg-primary px-6 py-3.5 font-semibold text-primary-foreground transition-opacity hover:opacity-90 sm:w-auto">
        {t("Find a Pretty Good collection point")}
      </a>}
      <ol className="mt-6 flex flex-wrap gap-x-6 gap-y-2 border-t border-current/10 pt-4 text-sm">
        {lifecycle.map((step, i) => <li key={step.label} className="flex items-center gap-2">
          <span className={`grid h-5 w-5 place-items-center rounded-full text-xs font-semibold ${step.done ? "bg-lime text-lime-foreground" : "bg-muted text-muted-foreground"}`}>
            {step.done ? <Check className="h-3 w-3" aria-hidden /> : i + 1}
          </span>
          <span className={step.done ? "font-medium" : "opacity-70"}>{t(step.label)}{!step.done && i === 2 ? ` (${t("pending")})` : ""}</span>
        </li>)}
      </ol>
    </section>

    {isLikely && <section id="pg-locations" className="mt-10" aria-labelledby="pg-where">
      <h2 id="pg-where" className="text-2xl font-semibold">{t("Where to bring it")}</h2>
      <ul className="mt-5 grid gap-3 sm:grid-cols-2">
        {prettyGoodLocations.map((loc) => <li key={loc.id} className="rounded-xl border border-border p-5">
          <div className="flex items-start gap-3">
            <MapPin className="mt-0.5 h-5 w-5 shrink-0 text-directory-icon" aria-hidden />
            <div className="min-w-0">
              <h3 className="font-semibold">{loc.name}</h3>
              <p className="text-sm text-muted-foreground">{t(loc.address)}</p>
              <p className="mt-1 text-sm">{t(loc.hours)}</p>
              <FreshnessLine lastVerified={loc.lastVerified} />
            </div>
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            <a href={mapsUrl(loc)} target="_blank" rel="noreferrer" className="btn btn-outline !px-4 !py-2 text-sm">
              {t("Open in maps")}<ExternalLink className="h-3.5 w-3.5" aria-hidden />
            </a>
            <button type="button" aria-pressed={chosen === loc.id} onClick={() => { setChosen(loc.id); trackPilotEvent("pretty_good_location_selected", loc.id); trackPilotEvent("destination_selected", loc.id); }} className={`btn !px-4 !py-2 text-sm ${chosen === loc.id ? "btn-lime" : "btn-primary"}`}>
              {chosen === loc.id ? t("Selected") : t("Choose this location")}
            </button>
          </div>
          <ReportOutdated target={loc.id} />
        </li>)}
      </ul>
    </section>}

    <SourceCards sources={prettyGoodSources} />

    <details className="group mt-10 rounded-xl border border-border">
      <summary className="flex cursor-pointer list-none items-center justify-between gap-3 p-5 font-semibold [&::-webkit-details-marker]:hidden">
        {t("Why am I seeing this recommendation?")}
        <ChevronDown className="h-4 w-4 transition-transform group-open:rotate-180" aria-hidden />
      </summary>
      <dl className="grid gap-3 border-t border-border p-5 sm:grid-cols-2">
        {([
          ["Detected item", t(detected.item)],
          ["Estimated condition", t(detected.condition)],
          ["Recommended route", isLikely ? "Pretty Good Basel" : t(actionLabels[assessment.alternative === "unsure" ? "repair" : assessment.alternative])],
          ["Confidence", `${assessment.confidence}%`],
          ["Source", "Basel-Stadt / Pretty Good Basel"],
          ["Maintained by", "Pretty Good Basel"],
          ["Rule", "PG-LAMP-004"],
          ["Status", t("Partner verified")],
          ["Rule used", t("Pretty Good accepts functional or lightly damaged household items")],
          ["Reuse potential", t(assessment.reusePotential)],
          ["Alternative route", assessment.alternative === "unsure" ? t("Check with the collection point") : t(actionLabels[assessment.alternative])],
        ] as const).map(([label, value]) => <div key={label} className="rounded-lg bg-muted/60 px-4 py-3">
          <dt className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{t(label)}</dt>
          <dd className="mt-1 font-medium">{value}</dd>
        </div>)}
      </dl>
      <div className="border-t border-border px-5 py-4">
        <FreshnessLine lastVerified={prettyGoodSources[0]!.lastVerified} />
      </div>
    </details>

    <section className="mt-10 rounded-xl border border-border p-5" aria-labelledby="pg-outcome">
      <h2 id="pg-outcome" className="font-semibold">{t("What happened next?")}</h2>
      {outcome === null ? <div className="mt-3 flex flex-wrap gap-2">
        {outcomeOptions.map((o) => <button key={o.id} type="button" className="btn btn-outline !px-4 !py-2 text-sm" onClick={() => pickOutcome(o.id)}>{t(o.label)}</button>)}
      </div> : <>
        <p className="mt-3 text-sm text-muted-foreground">{t("Thanks, your outcome was recorded.")}</p>
        {outcome === "rejected" && <div className="mt-4 border-t border-border pt-4">
          <p className="text-sm font-semibold">{t("Do you know why?")}</p>
          {rejectionReason === null ? <div className="mt-2 flex flex-wrap gap-2">
            {rejectionReasons.map((r) => <button key={r} type="button" className="rounded-full border border-input px-3 py-1.5 text-sm hover:border-primary hover:text-primary" onClick={() => setRejectionReason(r)}>{t(r)}</button>)}
          </div> : <>
            <p className="mt-2 text-sm text-muted-foreground">{t(rejectionReason)}</p>
            {rejectionReason === "Other" && <textarea value={rejectionText} onChange={(e) => setRejectionText(e.target.value)} placeholder={t("Tell us briefly what happened")} className="mt-2 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm" rows={2} />}
          </>}
        </div>}
      </>}

      <div className="mt-6 border-t border-border pt-5">
        <h3 className="font-semibold">{t("Was Wiiter's recommendation correct?")}</h3>
        {accuracy === null ? <div className="mt-3 flex flex-wrap gap-2">
          {([["yes", "Yes"], ["partly", "Partly"], ["no", "No"]] as const).map(([value, label]) =>
            <button key={value} type="button" className="btn btn-outline !px-4 !py-2 text-sm" onClick={() => pickAccuracy(value)}>{t(label)}</button>)}
        </div> : <>
          <p className="mt-3 text-sm text-muted-foreground">{t("Thanks for your feedback!")}</p>
          {accuracy !== "yes" && <div className="mt-3">
            <label className="text-sm font-medium" htmlFor="pg-improve">{t("What should we improve?")}</label>
            <textarea id="pg-improve" value={improveText} onChange={(e) => setImproveText(e.target.value)} placeholder={t("Optional")} className="mt-2 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm" rows={2} />
          </div>}
        </>}
      </div>
    </section>
  </div>;
}
