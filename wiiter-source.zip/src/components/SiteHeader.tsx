import { Link } from "@tanstack/react-router";
import { Leaf } from "lucide-react";
import { useLanguage, useT } from "@/lib/i18n";

const nav = [
  { to: "/explore", label: "Directory" },
  { to: "/impact", label: "Impact" },
] as const;

export function SiteHeader() {
  const t = useT();
  const { lang, setLang } = useLanguage();
  return (
    <header className="border-b border-border bg-background/90 backdrop-blur sticky top-0 z-20">
      <div className="container-page flex min-h-16 flex-wrap items-center justify-between gap-3 py-3 md:grid md:grid-cols-[1fr_auto_1fr] md:flex-nowrap">
        <Link to="/" className="flex items-center gap-2 font-semibold tracking-tight justify-self-start">
          <span className="grid h-8 w-8 place-items-center rounded-full bg-primary text-primary-foreground">
            <Leaf className="h-4 w-4" aria-hidden />
          </span>
          <span>Wiiter</span>
        </Link>
        <nav className="flex flex-wrap items-center justify-center gap-1 text-sm justify-self-center">
          {nav.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              className="whitespace-nowrap rounded-full px-3 py-1.5 text-muted-foreground hover:text-foreground"
              activeProps={{ className: "bg-accent text-accent-foreground" }}
            >
              {t(n.label)}
            </Link>
          ))}
        </nav>
        <div
          className="flex items-center rounded-full border border-input p-0.5 text-xs font-semibold justify-self-end"
          role="group"
          aria-label={t("Language")}
        >
          {(["de", "en"] as const).map((l) => (
            <button
              key={l}
              type="button"
              onClick={() => setLang(l)}
              aria-pressed={lang === l}
              className={`rounded-full px-2.5 py-1 transition-colors ${
                lang === l ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {l.toUpperCase()}
            </button>
          ))}
        </div>
      </div>
    </header>
  );
}

export function SiteFooter() {
  const t = useT();
  return (
    <footer className="mt-24 border-t border-border">
      <div className="container-page py-8 text-sm text-muted-foreground flex flex-col gap-2">
        <p>{t("Wiiter complements existing reuse infrastructure. It helps residents identify the right next step before travelling to a collection point.")}</p>
        <div className="flex flex-col md:flex-row gap-2 justify-between">
          <p>{t("Wiiter — a prototype civic service.")}</p>
          <p>{t("Directory sources are labelled. Outcomes stay on this device.")}</p>
        </div>
      </div>
    </footer>
  );
}
