import { useEffect, useRef, useState } from "react";
import { Camera, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useT } from "@/lib/i18n";

export function ItemPhoto({ file, onChange }: { file: File | null; onChange: (file: File | null) => void }) {
  const t = useT();
  const input = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!file) {
      setPreview(null);
      return;
    }
    const url = URL.createObjectURL(file);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  return (
    <section className="mt-6 border-t border-border pt-6" aria-label={t("Item photo")}>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-sm font-semibold">{t("Item photo")} <span className="font-normal text-muted-foreground">{t("(optional)")}</span></h2>
        <Button type="button" variant="outline" onClick={() => input.current?.click()}>
          <Camera aria-hidden /> {file ? t("Change photo") : t("Upload photo")}
        </Button>
      </div>
      <input
        ref={input}
        type="file"
        accept="image/*"
        aria-label={t("Upload item photo")}
        className="sr-only"
        onChange={(event) => {
          const selected = event.target.files?.[0];
          event.target.value = "";
          if (!selected) return;
          if (!selected.type.startsWith("image/")) {
            setError(t("Please choose an image file."));
            return;
          }
          setError("");
          onChange(selected);
        }}
      />
      {preview && (
        <div className="relative mt-4">
          <img
            src={preview}
            alt={t("Your item photo")}
            className="h-48 w-full rounded-lg border border-border bg-muted object-contain sm:h-64"
            onError={() => { setError(t("This photo cannot be displayed. Please try a JPG, PNG or WebP image.")); onChange(null); }}
          />
          <Button type="button" variant="outline" size="icon" title={t("Remove photo")} aria-label={t("Remove photo")} className="absolute right-3 top-3" onClick={() => { onChange(null); setError(""); }}>
            <Trash2 aria-hidden />
          </Button>
          <p className="mt-2 break-all text-xs text-muted-foreground">{file?.name}</p>
        </div>
      )}
      {error && <p role="alert" className="mt-3 text-sm text-destructive">{error}</p>}
    </section>
  );
}
