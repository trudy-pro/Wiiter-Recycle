import { Link } from "@tanstack/react-router";
import { AlertCircle, ArrowRight, Check, Heart, Recycle, Wrench } from "lucide-react";
import { useT } from "@/lib/i18n";
import type { Recommendation } from "@/lib/engine";
import type { CompleteAnswers } from "@/data/types";
import { actionLabels } from "@/data/labels";
import { ActionIcon } from "@/components/ActionIcon";

// Featured repair places shown directly below the recommendation; ids refer to src/data/options.ts.
const repairCards = [
  { id: "basel-reparierbar", name: "reparierBar Basel", category: "Community repair · Electronics", when: "Regular repair events · check next date", cost: "Low cost / community based", tags: ["Electronics", "Clothing", "Household"] },
  { id: "repair-directory", name: "Reparaturführer.ch", category: "Repair directory · All items", when: "Online · Basel area search", cost: "Free to search", tags: ["Businesses", "Advice"] },
  { id: "ex-electronics-repair", name: "Electronics repair workshop", category: "Electronics repair · Basel", when: "Example opening hours: Mon to Fri", cost: "Diagnosis fee usually applies", tags: ["Example", "Small appliances"] },
] as const;

const reasons = ["The item is damaged but may still be usable", "A small repair could extend its life", "Community repair can often be low cost"];
const beforeYouGo = ["Bring the charger, cable, or accessories", "Note what is wrong and when it started", "Take a photo of the model number", "Ask for a quote before approving paid work"];
const nextSteps = ["Choose a repair option", "Get the item checked", "Decide whether the repair is worth it"];

const repairSearch = { action: "repair", directoryItem: "electronics", recommended: "repair" } as const;

export function RepairRecommendation({ recommendation, answers }: { recommendation?: Recommendation; answers?: CompleteAnswers }) {
  const t = useT();
  const action = recommendation?.primary.action ?? "repair";
  const isRepair = action === "repair";
  const search = answers ? { action, item: answers.item, recommended: action } : repairSearch;
  const cards = recommendation ? recommendation.providers.map((p) => ({ id: p.id, name: p.title, category: p.description, when: p.hours ?? "Check before you go", cost: p.cost ?? "Check before you go", tags: p.verificationStatus === "example" ? ["Example"] : [] })) : repairCards;
  const displayedReasons = recommendation?.primary.reasons ?? reasons;
  const displayedChecklist = recommendation?.checklist ?? beforeYouGo;
  return <div className="container-page max-w-4xl pt-10 md:pt-14">
    <section className="rounded-2xl bg-foreground p-6 text-background md:p-8">
      <div className="flex items-center gap-4">
        <span className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-lime text-lime-foreground"><ActionIcon action={action} className="h-6 w-6" /></span>
        <div className="min-w-0">
          <p className="text-sm opacity-70">{t("Recommended for your item")}</p>
          <h1 className="text-2xl font-semibold leading-tight md:text-3xl">{isRepair ? t("Repair is your best next step") : t(actionLabels[action])}</h1>
        </div>
      </div>
      <p className="mt-4 opacity-80">{t(isRepair ? "A small fix could extend this item’s life." : "Your recommended next step")}</p>
      <Link to="/explore" search={search} className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full bg-lime px-6 py-3.5 font-semibold text-lime-foreground transition-opacity hover:opacity-90 sm:w-auto">
        {t(isRepair ? "Find repair options" : "Options for your recommended next step")}<ArrowRight className="h-4 w-4" aria-hidden />
      </Link>
    </section>

    <section className="mt-8" aria-labelledby="why-repair">
      <h2 id="why-repair" className="text-lg font-semibold">{t(isRepair ? "Why we recommend repair" : "Why this fits your answers")}</h2>
      <ul className="mt-3 space-y-2">{displayedReasons.map((r) => <li key={r} className="flex gap-3"><Check className="mt-1 h-4 w-4 shrink-0 text-foreground" aria-hidden />{t(r)}</li>)}</ul>
      {(recommendation?.notes ?? ["If you pass the item on, clearly mention the damage."]).map((note) => <p key={note} className="mt-4 flex items-start gap-2 rounded-xl bg-warning text-warning-foreground px-4 py-3 text-sm"><AlertCircle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />{t(note)}</p>)}
    </section>

    <section className="mt-12 border-t border-border pt-10" aria-labelledby="repair-options">
      <h2 id="repair-options" className="text-2xl font-semibold">{t(isRepair ? "Repair options in Basel" : "Options for your recommended next step")}</h2>
      <ul className="mt-5 grid gap-3">
        {cards.map((c) => <li key={c.id}>
          <Link to="/places/$placeId" params={{ placeId: c.id }} className="group grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4 rounded-xl border border-border p-5 transition-colors hover:bg-accent/30">
            <div className="min-w-0">
              <h3 className="font-semibold">{t(c.name)}</h3>
              <p className="text-sm text-muted-foreground">{t(c.category)}</p>
              <p className="mt-1 text-sm">{t(c.when)} · {t(c.cost)}</p>
              <div className="mt-2 flex flex-wrap gap-1.5">{c.tags.map((tag) => <span key={tag} className="rounded-full bg-muted px-2.5 py-0.5 text-xs">{t(tag)}</span>)}</div>
            </div>
            <span className="flex items-center gap-1 text-sm font-medium">{t("View details")}<ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" aria-hidden /></span>
          </Link>
        </li>)}
      </ul>
      <Link to="/explore" search={search} className="mt-4 inline-flex items-center gap-2 font-semibold underline-offset-4 hover:underline">{t(isRepair ? "View all repair options" : "Explore all options")}<ArrowRight className="h-4 w-4" aria-hidden /></Link>
    </section>

    <div className="mt-12 grid gap-10 border-t border-border pt-10 md:grid-cols-2">
      <section aria-labelledby="before-go">
        <h2 id="before-go" className="text-lg font-semibold">{t("Before you go")}</h2>
        <ul className="mt-3 space-y-2">{displayedChecklist.map((s) => <li key={s} className="flex gap-3"><Check className="mt-1 h-4 w-4 shrink-0 text-foreground" aria-hidden />{t(s)}</li>)}</ul>
      </section>
      <section aria-labelledby="next-steps">
        <h2 id="next-steps" className="text-lg font-semibold">{t("Your next steps")}</h2>
        <ol className="mt-3 space-y-2">{(isRepair ? nextSteps : recommendation?.checklist ?? nextSteps).map((s, i) => <li key={s} className="flex gap-3"><span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-muted text-xs font-semibold">{i + 1}</span>{t(s)}</li>)}</ol>
      </section>
    </div>

    <section className="mt-12 border-t border-border pt-10" aria-labelledby="fallback">
      <h2 id="fallback" className="text-lg font-semibold text-muted-foreground">{t(isRepair ? "If repair doesn’t work" : "Alternative routes")}</h2>
      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        {recommendation ? recommendation.alternatives.map((route) => <Link key={route.action} to="/explore" search={{ action: route.action, item: answers?.item }} className="flex gap-3 rounded-xl bg-muted/60 p-4 transition-colors hover:bg-muted"><ActionIcon action={route.action} className="mt-0.5 h-5 w-5 shrink-0 text-directory-icon" /><div><p className="font-semibold">{t(actionLabels[route.action])}</p><p className="text-sm text-muted-foreground">{t(route.reasons[0] ?? "Another possible route for your item.")}</p></div></Link>) : <>
          <Link to="/explore" search={{ action: "donate" }} className="flex gap-3 rounded-xl bg-muted/60 p-4 transition-colors hover:bg-muted"><Heart className="mt-0.5 h-5 w-5 shrink-0 text-directory-icon" aria-hidden /><div><p className="font-semibold">{t("Reuse or donate")}</p><p className="text-sm text-muted-foreground">{t("Pass it on only if it is safe and usable.")}</p></div></Link>
          <Link to="/explore" search={{ action: "recycle" }} className="flex gap-3 rounded-xl bg-muted/60 p-4 transition-colors hover:bg-muted"><Recycle className="mt-0.5 h-5 w-5 shrink-0 text-directory-icon" aria-hidden /><div><p className="font-semibold">{t("Recycle")}</p><p className="text-sm text-muted-foreground">{t("Find the appropriate local collection point.")}</p></div></Link>
        </>}
      </div>
    </section>
  </div>;
}
