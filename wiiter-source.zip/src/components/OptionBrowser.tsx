import { useState } from "react";
import { Search, X, SlidersHorizontal, MapPin, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { OptionGrid } from "@/components/OptionGrid";
import { PlaceSuggestion } from "@/components/PlaceSuggestion";
import { directoryLabels, directoryItemLabels } from "@/data/directory-labels";
import { actionLabels } from "@/data/labels";
import { options } from "@/data/options";
import type { ActionType, DirectoryCategory, DirectoryItem } from "@/data/types";
import { filterOptions, type OptionFilters } from "@/lib/option-filter";
import { useT } from "@/lib/i18n";

function Chip({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return <Button type="button" variant="ghost" onClick={onClick} aria-pressed={active} className={`h-auto whitespace-normal rounded-full border px-4 py-2 text-sm font-normal ${active ? "border-primary bg-primary text-primary-foreground hover:bg-primary hover:text-primary-foreground" : "border-input hover:border-primary"}`}>{children}</Button>;
}

export function OptionNotice() {
  const t = useT();
  return <p className="mt-4 max-w-3xl text-sm text-muted-foreground">{t("Check acceptance conditions before visiting. Official source entries and illustrative examples are labelled separately.")}</p>;
}

export function OptionBrowser({ filters, onChange, compact = false, recommendedAction }: { filters: OptionFilters; onChange: (filters: OptionFilters) => void; compact?: boolean; recommendedAction?: ActionType | undefined }) {
  const t = useT();
  const [more, setMore] = useState(false);
  const [suggest, setSuggest] = useState(false);
  const [context, setContext] = useState(true);
  const { q = "", action, category, directoryItem } = filters;
  const update = (patch: Partial<OptionFilters>) => onChange({ ...filters, ...patch });
  const results = filterOptions(options, filters, t);
  const activeCategory = category ?? action;
  const extraFilters = [["free", "Free"], ["appointmentRequired", "Appointment required"], ["acceptsDamaged", "Accepts damaged items"], ["pickupAvailable", "Pickup available"]] as const;
  return <>
    {recommendedAction && context && <aside className="mt-6 flex items-start justify-between gap-3 rounded-lg bg-accent p-4 text-accent-foreground"><div><p className="font-medium">{t("Recommended for your item: X").replace("X", t(actionLabels[recommendedAction]))}</p><p className="mt-1 text-sm">{t("Browse places for your recommended next step, or choose another route.")}</p></div><Button size="icon" variant="ghost" aria-label={t("Dismiss recommendation context")} onClick={() => setContext(false)}><X /></Button></aside>}
    <div className="mt-8 space-y-5">
      <form className="flex flex-wrap items-end gap-3" onSubmit={(e) => { e.preventDefault(); document.getElementById(compact ? "inline-directory-results" : "directory-results")?.scrollIntoView({ behavior: "smooth", block: "start" }); }}>
        <label className="min-w-0 flex-[3] basis-64"><span className="mb-2 block text-sm font-medium">{t("Search by item or place")}</span><span className="relative block"><Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden /><Input value={q} onChange={(e) => update({ q: e.target.value || undefined })} placeholder={t("e.g. laptop, bicycle, clothes, furniture…")} className="h-12 rounded-full bg-card pl-11 pr-4" /></span></label>
        <label className="min-w-36 flex-1"><span className="mb-2 block text-sm font-medium">{t("Location")}</span><span className="flex h-12 items-center gap-2 rounded-full border bg-card px-4"><MapPin className="h-4 w-4 text-muted-foreground" /><select aria-label={t("Location")} className="min-w-0 flex-1 bg-transparent"><option>Basel</option></select></span></label>
        <Button type="submit" className="btn btn-primary h-12 whitespace-normal"><Search />{t("Search")}</Button>
      </form>
      <div className="flex flex-wrap gap-2" role="group" aria-label={t("Filter by action")}>
        <Chip active={!activeCategory} onClick={() => update({ action: undefined, category: undefined })}>{t("All")}</Chip>
        {(Object.keys(directoryLabels) as DirectoryCategory[]).map((key) => <Chip key={key} active={activeCategory === key} onClick={() => update({ action: undefined, category: activeCategory === key ? undefined : key })}>{t(directoryLabels[key])}</Chip>)}
      </div>
      <div className="flex flex-wrap gap-2" role="group" aria-label={t("Filter by item")}>
        <Chip active={!directoryItem && !filters.item} onClick={() => update({ directoryItem: undefined, item: undefined })}>{t("All items")}</Chip>
        {(Object.keys(directoryItemLabels) as DirectoryItem[]).map((key) => <Chip key={key} active={directoryItem === key} onClick={() => update({ item: undefined, directoryItem: directoryItem === key ? undefined : key })}>{t(directoryItemLabels[key])}</Chip>)}
      </div>
      <Button variant="ghost" className="px-0" aria-expanded={more} onClick={() => setMore(!more)}><SlidersHorizontal />{t("More filters")}</Button>
      {more && <div className="flex flex-wrap gap-x-6 gap-y-3 border-y py-4">{extraFilters.map(([key, label]) => <label key={key} className="flex items-center gap-2 text-sm"><input type="checkbox" checked={filters[key] ?? false} onChange={(e) => update({ [key]: e.target.checked || undefined })} className="h-4 w-4 accent-primary" />{t(label)}</label>)}</div>}
    </div>
    <div id={compact ? "inline-directory-results" : "directory-results"} className="mt-8 flex flex-wrap items-center justify-between gap-2 border-t pt-6"><p className="text-sm text-muted-foreground" aria-live="polite">{results.length === 1 ? t("1 result") : t("X results").replace("X", String(results.length))}</p>{Object.values(filters).some(Boolean) && <Button variant="ghost" onClick={() => onChange({})}><X />{t("Clear filters")}</Button>}</div>
    {results.length ? <OptionGrid entries={results} compact={compact} /> : <div className="py-12 text-center"><h2 className="text-xl font-semibold">{t("No exact match yet")}</h2><p className="mt-2 text-muted-foreground">{t("Try clearing a filter or choosing another route.")}</p><div className="mt-5 flex flex-wrap justify-center gap-3"><Button className="h-auto whitespace-normal btn btn-primary" onClick={() => onChange({})}>{t("Show all nearby options")}</Button><Button variant="outline" className="h-auto whitespace-normal" onClick={() => onChange({ category: "recycle" })}><ArrowRight />{t("Try recycling instead")}</Button><Button variant="ghost" onClick={() => setSuggest(true)}>{t("Suggest a place")}</Button></div></div>}
    <PlaceSuggestion key={String(suggest)} initiallyOpen={suggest} />
  </>;
}
