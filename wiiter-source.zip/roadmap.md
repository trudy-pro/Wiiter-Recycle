# Assessment and Explore journey
- [x] Share existing image cards and filters between assessment and Explore.
- [x] Add matching options, selectable alternatives and inline full browsing.
- [x] Preserve resolution, photo upload, translations and Impact.
- [x] Test filtering and verify the journey on desktop and mobile.

# Circular-economy directory
- [x] Keep the current design and omit maps entirely.
- [x] Add directory search, categories, practical filters and assessment context.
- [x] Add place details, transparent source information and local suggestion downloads.
- [x] Verify directory browsing, translations and assessment continuity.
- [x] Rename the Explore nav entry and home button to "Directory" (German "Verzeichnis").

# Replace Find my next step
- [x] Replace questions with grouped clickable resource cards from all three references.
- [x] Keep navigation, Explore and Impact unchanged; translate new content.
- [x] Verify link destinations, keyboard access, desktop and mobile layout; use Facebook group search where the exact group is unverified.

# Impact visualization
- [x] Match the reference's segmented arc, centred count, outcome badges and celebratory detail with existing colours.
- [x] Verify existing calculations and the Impact display in English and German on desktop and mobile.

# Repair recommendation page
- [x] Restore /assess to the compact repair recommendation shown before the four-question flow.
- [x] Verify English and German, the directory link, mobile layout and existing tests.

# Four-step assessment with preserved results
- [x] Restore the four questions before results, preserving the screenshot's recommendation design.
- [x] Verify answer-based recommendations, directory links and English/German flow.

# Copy style: no hyphens
- [x] Remove hyphens from all visible English and German text, including hour ranges.
- [x] Keep official names, addresses and URLs intact; verify every page in both languages.

# Rename to Wiiter
- [x] Replace the old name in the header wordmark, footer line, page titles and social preview titles.
- [x] Keep taglines about giving things a second chance; verify English and German in the browser.

# Navigation
- [x] Remove "Find my next step" from the header navigation; keep Directory, Impact and the language switch.
- [x] Confirm the home button and Impact call to action still open the four-step assessment.
# Pretty Good Basel routing layer
- [x] Add rule based Pretty Good eligibility module with transparent fit levels and demo collection points.
- [x] Show Pretty Good result card, locations, why drawer and feedback after the assessment.
- [x] Track pilot events locally and add mock /pilot dashboard with partnership messaging.
- [x] Verify demo lamp scenario, tests and English/German rendering.

# Trust and validation layers
- [x] Add source cards with source types, official badge and structured last verified dates.
- [x] Add freshness indicators (recent / verified / may be outdated) and report outdated info actions.
- [x] Add outcome tracking, rejection reasons, accuracy feedback and recommendation lifecycle.
- [x] Extend pilot events and /pilot with trust, outcome quality and routing funnel metrics.
- [x] Verify demo lamp scenario, tests and English/German rendering.

# Partner portal
- [x] Add /partner area with dashboard, locations, accepted items, rules, reports, history and settings.
- [x] Mock roles (Admin, Editor, Verifier, Viewer), demo orgs, audit log and freshness score, persisted locally.
- [x] Show Partner verified badge and provenance in the consumer result; extend /pilot with partner participation.
- [x] Verify role gating, verification flow, tests and English/German rendering.
