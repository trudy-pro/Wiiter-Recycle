<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Recommendation rules live in src/lib/engine.ts and demo data in src/data/; UI never hardcodes decision logic — keeps rules testable and data swappable.
- Client state (answers, outcomes) uses src/lib/store.ts with localStorage fallback to memory — no backend in MVP.
- Assessment photos use session-only File objects and revocable browser object URLs; do not persist or analyze them, preserving the MVP's local-only flow.
- DE/EN language switching lives in src/lib/i18n.tsx (LanguageProvider, useT) with the German dictionary in src/lib/translations.ts; English strings are the keys, data files stay English and components translate at render — never hardcode German text outside translations.ts, and wrap new UI strings in t().
- /assess presents four questions before rendering engine-driven results through RepairRecommendation; preserve its compact design and pass answer filters to /explore so recommendations and browsing stay consistent. ResourceDirectory remains available as a component.
- Directory taxonomy is separate from assessment answer categories; only explicitly known provider attributes match practical filters, avoiding fabricated eligibility.
- Directory suggestions download locally and saved places last for the visit; do not imply submissions or cross-session persistence without a connected service.
- Directory provider details live at /places/$placeId; keep provider facts and official source provenance in the shared option data so assessment and direct browsing stay consistent.
- Impact's arc visualization derives its segments from the existing second-life counts and uses semantic palette tokens; it must not introduce new impact calculations or imply a completion target.
